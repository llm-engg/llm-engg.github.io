#!/usr/bin/env python3
"""Phase 1: Download all corpus sources."""

import json
import os
import re
import time
from pathlib import Path

import arxiv
import requests
import wikipediaapi
from datasets import load_dataset
from tqdm import tqdm

RAW = Path("corpus/raw")
EVAL = Path("corpus/eval")

ARXIV_PAPERS = [
    ("2005.11401", "Lewis et al. — RAG", "RAG foundation"),
    ("2004.04906", "Karpukhin et al. — DPR", "Dense retrieval"),
    ("2004.12832", "Khattab & Zaharia — ColBERT", "Late interaction"),
    ("2112.01488", "Santhanam et al. — ColBERTv2", "Compression"),
    ("2104.08663", "Thakur et al. — BEIR", "Retrieval eval"),
    ("2112.09118", "Izacard et al. — Contriever", "Unsupervised dense"),
    ("2310.11511", "Asai et al. — Self-RAG", "Adaptive RAG"),
    ("2401.18059", "Sarthi et al. — RAPTOR", "Hierarchical indexing"),
    ("2404.16130", "Edge et al. — GraphRAG", "Graph RAG"),
    ("2407.01449", "Faysse et al. — ColPali", "Multimodal RAG"),
    ("2212.10496", "Gao et al. — HyDE", "Query expansion"),
    ("2210.07316", "Muennighoff et al. — MTEB", "Multilingual eval"),
    ("2307.03172", "Liu et al. — Lost in the Middle", "Context rot"),
    ("2407.12854", "Shao et al. — MassiveDS", "Datastore scaling"),
    ("2212.10511", "Mallen & Asai — Trust LMs", "RAG effectiveness"),
]

HF_MODELS = [
    "BAAI/bge-small-en-v1.5",
    "BAAI/bge-reranker-v2-m3",
    "intfloat/multilingual-e5-large",
    "colbert-ir/colbertv2.0",
    "vidore/colpali-v1.2",
]

WIKI_ARTICLES = [
    "Retrieval-augmented generation",
    "Information retrieval",
    "Vector database",
    "Knowledge graph",
    "Transformer (deep learning)",
]


def download_arxiv():
    """Download arXiv PDFs using wget (direct URL), then build metadata JSONs."""
    print("\n=== Phase 1.1: Downloading arXiv PDFs ===")
    manifest = []

    for arxiv_id, desc, topic in tqdm(ARXIV_PAPERS, desc="arXiv"):
        pdf_path = RAW / f"arxiv_{arxiv_id}.pdf"
        json_path = RAW / f"arxiv_{arxiv_id}.json"

        if pdf_path.exists():
            print(f"  {arxiv_id}: PDF already exists, skipping download")
        else:
            url = f"https://arxiv.org/pdf/{arxiv_id}"
            try:
                resp = requests.get(
                    url,
                    headers={"User-Agent": "Mozilla/5.0"},
                    timeout=120,
                    stream=True,
                )
                resp.raise_for_status()
                with open(pdf_path, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=8192):
                        f.write(chunk)
                print(f"  {arxiv_id}: downloaded PDF ({pdf_path.stat().st_size // 1024}KB)")
                time.sleep(2)
            except Exception as e:
                print(f"  {arxiv_id}: PDF download ERROR — {e}")
                continue

        if json_path.exists():
            with open(json_path) as f:
                manifest.append(json.load(f))
        # JSON metadata is written separately by generate_metadata()

    manifest_path = RAW / "manifest.json"
    if manifest:
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)
    print(f"\nManifest entries: {len(manifest)}")
    return manifest


def download_hf_model_cards():
    print("\n=== Phase 1.2: Downloading HuggingFace Model Cards ===")
    for model_id in tqdm(HF_MODELS, desc="HF model cards"):
        sanitized = model_id.replace("/", "_")
        out_path = RAW / f"hf_{sanitized}.md"

        if out_path.exists():
            print(f"  {model_id}: already exists, skipping")
            continue

        url = f"https://huggingface.co/{model_id}/raw/main/README.md"
        try:
            resp = requests.get(url, timeout=30)
            resp.raise_for_status()
            out_path.write_text(resp.text, encoding="utf-8")
            print(f"  {model_id}: downloaded ({len(resp.text)} chars)")
            time.sleep(0.5)
        except Exception as e:
            print(f"  {model_id}: ERROR — {e}")


def download_wikipedia():
    print("\n=== Phase 1.3: Downloading Wikipedia Articles ===")
    wiki = wikipediaapi.Wikipedia(
        user_agent="RAGCourseDemo/1.0 (research project)",
        language="en",
    )

    for title in tqdm(WIKI_ARTICLES, desc="Wikipedia"):
        sanitized = re.sub(r"[^\w]+", "_", title).strip("_")
        out_path = RAW / f"wiki_{sanitized}.txt"

        if out_path.exists():
            print(f"  {title}: already exists, skipping")
            continue

        try:
            page = wiki.page(title)
            if not page.exists():
                print(f"  {title}: page not found")
                continue
            out_path.write_text(page.text, encoding="utf-8")
            print(f"  {title}: downloaded ({len(page.text)} chars)")
            time.sleep(0.5)
        except Exception as e:
            print(f"  {title}: ERROR — {e}")


def download_qasper():
    print("\n=== Phase 1.4: Downloading QASPER (for eval) ===")
    out_path = EVAL / "qasper_100.json"
    if out_path.exists():
        print("  QASPER: already exists, skipping")
        return

    try:
        qasper = load_dataset("allenai/qasper", split="validation", trust_remote_code=True)
        results = []
        for item in qasper:
            for q_idx, question in enumerate(item.get("qas", {}).get("question", [])):
                if len(results) >= 100:
                    break
                answers = item["qas"]["answers"][q_idx]["answer"]
                # Filter: only extractive or abstractive answers
                valid_answers = [
                    a for a in answers
                    if a.get("answer_type") in ("extractive", "abstractive")
                ]
                if not valid_answers:
                    continue

                answer = valid_answers[0]
                answer_text = ""
                if answer.get("answer_type") == "extractive":
                    spans = answer.get("extractive_spans", [])
                    answer_text = " ".join(spans)
                elif answer.get("answer_type") == "abstractive":
                    answer_text = answer.get("free_form_answer", "")

                if not answer_text:
                    continue

                # Get relevant paragraphs from evidence
                relevant_paragraphs = []
                for ev in answer.get("evidence", []):
                    paragraphs = ev.get("paragraphs", [])
                    relevant_paragraphs.extend(paragraphs)

                results.append({
                    "question": question,
                    "answer": answer_text,
                    "paper_title": item.get("title", ""),
                    "relevant_paragraphs": relevant_paragraphs,
                })

            if len(results) >= 100:
                break

        results = results[:100]
        out_path.write_text(json.dumps(results, indent=2))
        print(f"  QASPER: saved {len(results)} Q&A pairs")
    except Exception as e:
        print(f"  QASPER: ERROR — {e}")


def download_hotpotqa():
    print("\n=== Phase 1.5: Downloading HotpotQA subset (multi-hop) ===")
    out_path = EVAL / "hotpot_50.json"
    if out_path.exists():
        print("  HotpotQA: already exists, skipping")
        return

    try:
        hotpot = load_dataset("hotpot_qa", "distractor", split="validation", trust_remote_code=True)
        bridge = [item for item in hotpot if item.get("type") == "bridge"][:50]

        results = []
        for item in bridge:
            results.append({
                "question": item["question"],
                "answer": item["answer"],
                "supporting_facts": {
                    "title": item["supporting_facts"]["title"],
                    "sent_id": item["supporting_facts"]["sent_id"],
                },
            })

        out_path.write_text(json.dumps(results, indent=2))
        print(f"  HotpotQA: saved {len(results)} bridge questions")
    except Exception as e:
        print(f"  HotpotQA: ERROR — {e}")


if __name__ == "__main__":
    os.chdir(Path(__file__).parent.parent)  # ensure we're at /projects/rag/
    print(f"Working directory: {Path.cwd()}")

    # download_arxiv()
    download_hf_model_cards()
    download_wikipedia()
    download_qasper()
    download_hotpotqa()

    print("\n=== Phase 1 Complete ===")
    # Print summary
    raw_files = list(RAW.iterdir())
    pdfs = [f for f in raw_files if f.suffix == ".pdf"]
    mds = [f for f in raw_files if f.suffix == ".md"]
    txts = [f for f in raw_files if f.suffix == ".txt"]
    jsons = [f for f in raw_files if f.suffix == ".json" and f.name != "manifest.json"]
    print(f"  PDFs: {len(pdfs)}")
    print(f"  Markdown (HF): {len(mds)}")
    print(f"  Text (Wiki): {len(txts)}")
    print(f"  Metadata JSONs: {len(jsons)}")
    eval_files = list(EVAL.iterdir())
    print(f"  Eval files: {[f.name for f in eval_files]}")
