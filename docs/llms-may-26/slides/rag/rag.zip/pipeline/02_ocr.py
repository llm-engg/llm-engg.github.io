#!/usr/bin/env python3
"""Phase 2: OCR — Convert raw sources to clean markdown."""

import json
import os
import re
import shutil
import sys
from pathlib import Path

from tqdm import tqdm

RAW = Path("corpus/raw")
MARKDOWN = Path("corpus/markdown")
GRAPH = Path("corpus/graph")

ARXIV_IDS = [
    "2005.11401", "2004.04906", "2004.12832", "2112.01488", "2104.08663",
    "2112.09118", "2310.11511", "2401.18059", "2404.16130", "2407.01449",
    "2212.10496", "2210.07316", "2307.03172", "2407.12854", "2212.10511",
]

HF_MODELS = [
    "BAAI/bge-small-en-v1.5",
    "BAAI/bge-reranker-v2-m3",
    "intfloat/multilingual-e5-large",
    "colbert-ir/colbertv2.0",
    "vidore/colpali-v1.2",
]

WIKI_ARTICLES = [
    "Retrieval-augmented generation",
    "Information retrieval",
    "Vector database",
    "Knowledge graph",
    "Transformer (deep learning)",
]


# ── helpers ──────────────────────────────────────────────────────────────────

def postprocess_arxiv_md(text: str, arxiv_id: str) -> tuple[str, str]:
    """Clean arxiv markdown. Returns (cleaned_text, refs_text)."""
    # Strip arXiv watermark lines
    text = re.sub(r"arXiv:\d{4}\.\d{4,5}[^\n]*\n?", "", text)

    # Extract and remove References/Bibliography section
    refs_text = ""
    refs_pattern = re.compile(
        r"(#{1,3}\s*(References|Bibliography|Works Cited)\b.*)",
        re.IGNORECASE | re.DOTALL,
    )
    m = refs_pattern.search(text)
    if m:
        refs_text = text[m.start():]
        text = text[: m.start()]

    # Normalize multiple blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)

    # Rejoin hyphenated line breaks
    text = re.sub(r"(\w+)-\n(\w+)", r"\1\2", text)

    return text.strip(), refs_text.strip()


def strip_yaml_frontmatter(text: str) -> tuple[str, dict]:
    """Strip YAML frontmatter. Returns (body, meta_dict)."""
    meta = {}
    if not text.startswith("---"):
        return text, meta

    end = text.find("\n---", 3)
    if end == -1:
        return text, meta

    yaml_block = text[3:end].strip()
    body = text[end + 4:].lstrip("\n")

    for line in yaml_block.splitlines():
        m = re.match(r"^([\w\-]+)\s*:\s*(.*)", line)
        if m:
            meta[m.group(1)] = m.group(2).strip()

    return body, meta


def sanitize_name(name: str) -> str:
    return re.sub(r"[^\w]+", "_", name).strip("_")


def run_marker(pdf_path: Path) -> str | None:
    """Run Marker OCR on a PDF and return the markdown text."""
    try:
        from marker.converters.pdf import PdfConverter
        from marker.models import create_model_dict
        from marker.output import text_from_rendered

        converter = PdfConverter(artifact_dict=create_model_dict())
        rendered = converter(str(pdf_path))
        text, _, _images = text_from_rendered(rendered)
        return text
    except Exception as e:
        print(f"    Marker error: {e}")
        return None


# ── Phase 2.1: arXiv PDFs via Marker ─────────────────────────────────────────

def convert_arxiv_pdfs():
    print("\n=== Phase 2.1: Converting arXiv PDFs with Marker ===")

    for arxiv_id in tqdm(ARXIV_IDS, desc="Marker OCR"):
        pdf_path = RAW / f"arxiv_{arxiv_id}.pdf"
        out_md = MARKDOWN / f"arxiv_{arxiv_id}.md"
        refs_out = GRAPH / f"refs_arxiv_{arxiv_id}.txt"

        if not pdf_path.exists():
            print(f"  {arxiv_id}: PDF not found, skipping")
            continue

        if out_md.exists() and refs_out.exists():
            print(f"  {arxiv_id}: already processed, skipping")
            continue

        print(f"  {arxiv_id}: running Marker OCR...")
        raw_md = run_marker(pdf_path)

        if raw_md is None:
            print(f"  {arxiv_id}: OCR failed")
            continue

        cleaned, refs = postprocess_arxiv_md(raw_md, arxiv_id)
        out_md.write_text(cleaned, encoding="utf-8")
        refs_out.write_text(refs, encoding="utf-8")
        print(f"  {arxiv_id}: done ({len(cleaned):,} chars, refs: {len(refs):,} chars)")


# ── Phase 2.2: HuggingFace Model Cards ───────────────────────────────────────

def convert_hf_model_cards():
    print("\n=== Phase 2.2: Processing HuggingFace Model Cards ===")

    for model_id in tqdm(HF_MODELS, desc="HF model cards"):
        sanitized = model_id.replace("/", "_")
        src = RAW / f"hf_{sanitized}.md"
        dst = MARKDOWN / f"hf_{sanitized}.md"
        meta_dst = MARKDOWN / f"hf_{sanitized}_meta.json"

        if not src.exists():
            print(f"  {model_id}: source not found, skipping")
            continue

        if dst.exists():
            print(f"  {model_id}: already processed, skipping")
            continue

        text = src.read_text(encoding="utf-8")
        body, meta = strip_yaml_frontmatter(text)
        meta["hf_model_id"] = model_id

        dst.write_text(body, encoding="utf-8")
        meta_dst.write_text(json.dumps(meta, indent=2), encoding="utf-8")
        print(f"  {model_id}: processed ({len(body):,} chars)")


# ── Phase 2.3: Wikipedia Articles ────────────────────────────────────────────

def convert_wikipedia():
    print("\n=== Phase 2.3: Processing Wikipedia Articles ===")

    for title in tqdm(WIKI_ARTICLES, desc="Wikipedia"):
        sanitized = sanitize_name(title)
        src = RAW / f"wiki_{sanitized}.txt"
        dst = MARKDOWN / f"wiki_{sanitized}.md"

        if not src.exists():
            print(f"  {title}: source not found, skipping")
            continue

        if dst.exists():
            print(f"  {title}: already processed, skipping")
            continue

        text = src.read_text(encoding="utf-8")

        # Strip from == See also == to end
        text = re.sub(r"\n==\s*See also\s*==.*", "", text, flags=re.DOTALL | re.IGNORECASE)

        # Strip citation markers [1], [23], etc.
        text = re.sub(r"\[\d+\]", "", text)

        # Add top-level heading if not present
        if not text.strip().startswith("# "):
            text = f"# {title}\n\n{text}"

        # Normalize blank lines
        text = re.sub(r"\n{3,}", "\n\n", text)

        dst.write_text(text.strip(), encoding="utf-8")
        print(f"  {title}: processed ({len(text):,} chars)")


# ── Phase 2.4: Validation ─────────────────────────────────────────────────────

def validate():
    print("\n=== Phase 2.4: Validation ===")
    print(f"\n{'File':<50} {'Chars':>8} {'##-count':>8} {'Status'}")
    print("-" * 78)

    issues = []

    for arxiv_id in ARXIV_IDS:
        md = MARKDOWN / f"arxiv_{arxiv_id}.md"
        if not md.exists():
            print(f"  arxiv_{arxiv_id}.md{'':<31} {'---':>8} {'---':>8} MISSING")
            issues.append(f"MISSING: arxiv_{arxiv_id}.md")
            continue
        text = md.read_text(encoding="utf-8")
        n_sections = text.count("##")
        status = "OK"
        if len(text) < 3000:
            issues.append(f"SHORT: arxiv_{arxiv_id}.md ({len(text)} chars)")
            status = "SHORT"
        for artifact in ["obj\n", "endobj", "stream\n"]:
            if artifact in text:
                issues.append(f"ARTIFACT in arxiv_{arxiv_id}.md")
                status = "ARTIFACT"
        print(f"  arxiv_{arxiv_id}.md{'':<31} {len(text):>8,} {n_sections:>8} {status}")

    for model_id in HF_MODELS:
        sanitized = model_id.replace("/", "_")
        md = MARKDOWN / f"hf_{sanitized}.md"
        name = f"hf_{sanitized}.md"
        if not md.exists():
            print(f"  {name:<48} {'---':>8} {'---':>8} MISSING")
            issues.append(f"MISSING: {name}")
            continue
        text = md.read_text(encoding="utf-8")
        n_sections = text.count("##")
        print(f"  {name:<48} {len(text):>8,} {n_sections:>8} OK")

    for title in WIKI_ARTICLES:
        sanitized = sanitize_name(title)
        md = MARKDOWN / f"wiki_{sanitized}.md"
        name = f"wiki_{sanitized}.md"
        if not md.exists():
            print(f"  {name:<48} {'---':>8} {'---':>8} MISSING")
            issues.append(f"MISSING: {name}")
            continue
        text = md.read_text(encoding="utf-8")
        n_sections = text.count("##")
        print(f"  {name:<48} {len(text):>8,} {n_sections:>8} OK")

    print()
    if issues:
        print(f"Issues found ({len(issues)}):")
        for iss in issues:
            print(f"  - {iss}")
    else:
        print("All validation checks passed.")


# ── main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    os.chdir(Path(__file__).parent.parent)
    print(f"Working directory: {Path.cwd()}")

    convert_arxiv_pdfs()
    convert_hf_model_cards()
    convert_wikipedia()
    validate()

    print("\n=== Phase 2 Complete ===")
