#!/usr/bin/env python3
"""Phase 3: Chunking Pipeline — LangChain-based chunking for all document types.

Strategy per document type:
  arXiv papers     → MarkdownHeaderTextSplitter (all heading levels)
                     + RecursiveCharacterTextSplitter (markdown separators,
                       chunk_size=400 tok, overlap=50 tok)
  HF model cards   → MarkdownHeaderTextSplitter (## / ### headers only)
                     + RecursiveCharacterTextSplitter (markdown separators,
                       chunk_size=400 tok, overlap=0)
  Wikipedia        → RecursiveCharacterTextSplitter (paragraph-first,
                       chunk_size=350 tok, overlap=0)
"""

import json
import re
import os
from pathlib import Path

from langchain_text_splitters import (
    MarkdownHeaderTextSplitter,
    RecursiveCharacterTextSplitter,
)

# ── Constants ─────────────────────────────────────────────────────────────────

MARKDOWN = Path("corpus/markdown")
CHUNKS_DIR = Path("corpus/chunks")
RAW = Path("corpus/raw")

ARXIV_IDS = [
    "2005.11401", "2004.04906", "2004.12832", "2112.01488", "2104.08663",
    "2112.09118", "2310.11511", "2401.18059", "2404.16130", "2407.01449",
    "2212.10496", "2210.07316", "2307.03172", "2407.12854", "2212.10511",
]

HF_MODELS = [
    "BAAI/bge-small-en-v1.5",
    "BAAI/bge-reranker-v2-m3",
    "intfloat/multilingual-e5-large",
    "colbert-ir/colbertv2.0",
    "vidore/colpali-v1.2",
]

WIKI_ARTICLES = [
    "Retrieval-augmented generation",
    "Information retrieval",
    "Vector database",
    "Knowledge graph",
    "Transformer (deep learning)",
]

# ── Token counting (used as length_function in all splitters) ─────────────────

def count_tokens(text: str) -> int:
    """Approximate token count: whitespace word count × 1.3."""
    return int(len(text.split()) * 1.3)


# ── Content feature detection ─────────────────────────────────────────────────

def detect_has_math(text: str) -> bool:
    return bool(re.search(
        r'\$|\\\w+\{|\\frac|\\sum|\\int|\\alpha|\\beta|\\theta|\\sigma|\\nabla',
        text,
    ))

def detect_has_code(text: str) -> bool:
    return "```" in text

def detect_has_table(text: str) -> bool:
    lines = text.split("\n")
    pipe_lines = [l for l in lines if "|" in l and l.strip().startswith("|")]
    sep_lines  = [l for l in lines if re.match(r"^\s*\|[-: |]+\|\s*$", l)]
    return len(pipe_lines) >= 2 and len(sep_lines) >= 1


# ── HTML helpers (Marker OCR embeds spans in headings) ────────────────────────

def strip_html(text: str) -> str:
    """Remove HTML tags and decode common entities."""
    text = re.sub(r"<[^>]+>", "", text)
    for entity, char in [("&lt;", "<"), ("&gt;", ">"), ("&amp;", "&"), ("&nbsp;", " ")]:
        text = text.replace(entity, char)
    return text

def clean_heading_text(text: str) -> str:
    """Strip HTML tags and markdown bold/italic from a heading string."""
    text = strip_html(text)
    text = re.sub(r"\*+([^*]*)\*+", r"\1", text)   # **bold** / *italic*
    text = re.sub(r"_+([^_]*)_+", r"\1", text)
    return text.strip()


# ── Page-number tracking (Marker inserts spans in heading lines) ──────────────

def build_heading_page_map(original_text: str) -> dict[str, int]:
    """
    Return {clean_heading_text: first_page_number} by scanning the ORIGINAL
    (pre-strip) markdown for headings that carry or precede a page span.
    """
    # All span positions → page numbers
    span_re = re.compile(r'<span[^>]+id="page-(\d+)-[^"]*"[^>]*/?>(?:</span>)?')
    spans: list[tuple[int, int]] = [
        (m.start(), int(m.group(1))) for m in span_re.finditer(original_text)
    ]

    # Heading lines, optionally containing an inline span
    hdr_re = re.compile(
        r'^(#+)\s*(?:<span[^>]+id="page-(\d+)-[^"]*"[^>]*/?>(?:</span>)?\s*)?(.+?)$',
        re.MULTILINE,
    )

    mapping: dict[str, int] = {}
    last_page = 1

    for m in hdr_re.finditer(original_text):
        pos = m.start()
        inline_pg = m.group(2)
        if inline_pg:
            last_page = int(inline_pg)
        else:
            # Nearest preceding span
            for sp_pos, pg in reversed(spans):
                if sp_pos <= pos:
                    last_page = pg
                    break
        heading_clean = clean_heading_text(m.group(3))
        mapping[heading_clean] = last_page

    return mapping


# ── Splitter factories ────────────────────────────────────────────────────────

def make_recursive_splitter(
    chunk_size: int,
    chunk_overlap: int,
    separators: list[str] | None = None,
) -> RecursiveCharacterTextSplitter:
    """Build a token-aware RecursiveCharacterTextSplitter."""
    if separators is None:
        # Markdown-appropriate order: headings, code fences, blank lines, sentences
        separators = ["\n#{1,6} ", "```\n", "\n\n", "\n", ". ", " ", ""]
    return RecursiveCharacterTextSplitter(
        separators=separators,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=count_tokens,
        is_separator_regex=True,
    )


ARXIV_HEADER_SPLITTER = MarkdownHeaderTextSplitter(
    headers_to_split_on=[
        ("#",    "h1"),
        ("##",   "h2"),
        ("###",  "h3"),
        ("####", "h4"),
    ],
    strip_headers=False,   # keep heading text inside the chunk content
)

HF_HEADER_SPLITTER = MarkdownHeaderTextSplitter(
    headers_to_split_on=[
        ("##",   "h2"),
        ("###",  "h3"),
    ],
    strip_headers=False,
)


# ── arXiv paper chunking ──────────────────────────────────────────────────────

_IS_REFERENCES = re.compile(
    r"\b(references|bibliography|works\s+cited)\b", re.IGNORECASE
)

def chunk_arxiv(filepath: Path, doc_meta: dict) -> list[dict]:
    """
    1. Strip HTML from the text (keeps markdown intact).
    2. MarkdownHeaderTextSplitter → one Document per section.
    3. Skip References / Bibliography sections.
    4. Abstract → keep as single chunk.
    5. Sections > 600 tokens → RecursiveCharacterTextSplitter
       (chunk_size=400, overlap=50, markdown separators).
    6. Drop chunks < 60 tokens.
    """
    original_text = filepath.read_text(encoding="utf-8")
    arxiv_id = doc_meta["arxiv_id"]

    # Build heading→page map BEFORE stripping HTML
    heading_page_map = build_heading_page_map(original_text)

    # Strip HTML (span tags etc.) for actual chunking
    clean_text = strip_html(original_text)

    # ── Step 1: split by headers ───────────────────────────────────────────
    header_docs = ARXIV_HEADER_SPLITTER.split_text(clean_text)

    # Splitter for oversized sections
    recursive = make_recursive_splitter(chunk_size=400, chunk_overlap=50)

    chunks: list[dict] = []
    chunk_index = 0

    for sec_idx, doc in enumerate(header_docs):
        content = doc.page_content.strip()
        hdr_meta = doc.metadata   # {h1, h2, h3, h4} — whichever are present

        # Own heading = most specific key present (h4 > h3 > h2 > h1).
        # Use this for is_abstract / references checks so inherited parent
        # headers (e.g. h1="Abstract" above an h4="Introduction" section)
        # don't bleed into child sections.
        own_heading = clean_heading_text(
            hdr_meta.get("h4") or hdr_meta.get("h3") or
            hdr_meta.get("h2") or hdr_meta.get("h1") or ""
        )

        # Skip References / Bibliography
        if _IS_REFERENCES.search(own_heading) or _IS_REFERENCES.search(content[:200]):
            continue

        is_abstract = bool(re.search(r"\babstract\b", own_heading, re.IGNORECASE))

        # Section metadata: prefer h2 parent with h3/h4 subsection when
        # the hierarchy is clear; otherwise fall back to own_heading.
        if hdr_meta.get("h2") and (hdr_meta.get("h3") or hdr_meta.get("h4")):
            section    = clean_heading_text(hdr_meta["h2"])
            subsection = clean_heading_text(hdr_meta.get("h4") or hdr_meta.get("h3"))
        else:
            section    = own_heading
            subsection = None

        # Page number: look up any heading level in the map
        page_start = 1
        for hdr_text in hdr_meta.values():
            cleaned = clean_heading_text(hdr_text)
            if cleaned in heading_page_map:
                page_start = heading_page_map[cleaned]
                break

        # ── Step 2: chunk section content ─────────────────────────────────
        if is_abstract or count_tokens(content) <= 600:
            sub_texts = [content]
        else:
            sub_texts = recursive.split_text(content)

        for c_idx, chunk_text in enumerate(sub_texts):
            chunk_text = chunk_text.strip()
            if count_tokens(chunk_text) < 60 and not is_abstract:
                continue

            chunk_id = f"paper_{arxiv_id}_s{sec_idx}_c{c_idx:02d}"
            chunks.append({
                "text": chunk_text,
                "contextualized_text": "",
                "metadata": {
                    "chunk_id":    chunk_id,
                    "source_file": f"arxiv_{arxiv_id}.pdf",
                    "doc_type":    "paper",
                    "title":       doc_meta.get("title", ""),
                    "arxiv_id":    arxiv_id,
                    "authors":     doc_meta.get("authors", []),
                    "year":        doc_meta.get("year"),
                    "venue":       doc_meta.get("venue"),
                    "hf_model_id": None,
                    "language":    "en",
                    "section":     section,
                    "subsection":  subsection,
                    "page_start":  page_start,
                    "chunk_index": chunk_index,
                    "token_count": count_tokens(chunk_text),
                    "is_abstract": is_abstract,
                    "has_math":    detect_has_math(chunk_text),
                    "has_code":    detect_has_code(chunk_text),
                    "has_table":   detect_has_table(chunk_text),
                },
            })
            chunk_index += 1

    return chunks


# ── HuggingFace model card chunking ───────────────────────────────────────────

def chunk_hf_model_card(filepath: Path, doc_meta: dict) -> list[dict]:
    """
    1. MarkdownHeaderTextSplitter on ## / ### headers.
    2. Code blocks are atomic: extracted before splitting, restored after.
       RecursiveCharacterTextSplitter uses markdown separators so code
       fences are preferred split points — blocks shorter than chunk_size
       are never split internally.
    3. chunk_size=400 tokens, overlap=0.
    4. Drop chunks < 40 tokens.
    """
    text = filepath.read_text(encoding="utf-8")
    model_id = doc_meta.get("hf_model_id", "")
    sanitized_id = re.sub(r"[^\w]+", "_", model_id).strip("_")

    # Load YAML meta if available
    meta_file = filepath.parent / (filepath.stem + "_meta.json")
    yaml_meta: dict = {}
    if meta_file.exists():
        try:
            yaml_meta = json.loads(meta_file.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass

    # Protect code blocks: replace with single-line placeholders
    code_blocks: dict[str, str] = {}
    counter = [0]

    def _stash(m: re.Match) -> str:
        key = f"\n\n__CODEBLOCK_{counter[0]}__\n\n"
        code_blocks[key.strip()] = m.group(0)
        counter[0] += 1
        return key

    text_no_code = re.sub(r"```[\s\S]*?```", _stash, text)

    # ── Step 1: split by ## / ### headers ─────────────────────────────────
    header_docs = HF_HEADER_SPLITTER.split_text(text_no_code)

    # Splitter for oversized prose sections
    recursive = make_recursive_splitter(chunk_size=400, chunk_overlap=0)

    chunks: list[dict] = []
    chunk_index = 0

    for sec_idx, doc in enumerate(header_docs):
        content = doc.page_content.strip()
        hdr_meta = doc.metadata

        section    = clean_heading_text(hdr_meta.get("h2", ""))
        subsection = clean_heading_text(hdr_meta.get("h3", "")) or None

        # Prose token count (excluding code placeholders)
        prose = re.sub(r"__CODEBLOCK_\d+__", "", content)
        if count_tokens(prose) > 400:
            sub_texts = recursive.split_text(content)
        else:
            sub_texts = [content]

        for c_idx, chunk_text in enumerate(sub_texts):
            # Restore code blocks
            for placeholder, original in code_blocks.items():
                chunk_text = chunk_text.replace(placeholder, original)
            chunk_text = chunk_text.strip()

            if count_tokens(chunk_text) < 40:
                continue

            chunk_id = f"model_card_{sanitized_id}_s{sec_idx}_c{c_idx:02d}"
            chunks.append({
                "text": chunk_text,
                "contextualized_text": "",
                "metadata": {
                    "chunk_id":    chunk_id,
                    "source_file": f"hf_{sanitized_id}.md",
                    "doc_type":    "model_card",
                    "title":       yaml_meta.get("title", model_id),
                    "arxiv_id":    None,
                    "authors":     [],
                    "year":        None,
                    "venue":       None,
                    "hf_model_id": model_id,
                    "language":    "en",
                    "section":     section,
                    "subsection":  subsection,
                    "page_start":  None,
                    "chunk_index": chunk_index,
                    "token_count": count_tokens(chunk_text),
                    "is_abstract": False,
                    "has_math":    detect_has_math(chunk_text),
                    "has_code":    detect_has_code(chunk_text),
                    "has_table":   detect_has_table(chunk_text),
                },
            })
            chunk_index += 1

    return chunks


# ── Wikipedia article chunking ─────────────────────────────────────────────────

def chunk_wikipedia(filepath: Path, title: str) -> list[dict]:
    """
    RecursiveCharacterTextSplitter with paragraph-first separators.
    chunk_size=350 tokens, overlap=0.
    Lead paragraph (first block before any section) kept as own chunk.
    Drop chunks < 40 tokens.
    """
    text = filepath.read_text(encoding="utf-8")
    sanitized_title = re.sub(r"[^\w]+", "_", title).strip("_")

    # Remove the top-level # heading added in Phase 2
    text = re.sub(r"^#\s+.+\n+", "", text, count=1).strip()

    splitter = make_recursive_splitter(
        chunk_size=350,
        chunk_overlap=0,
        separators=["\n\n", ". ", "\n", " ", ""],
    )
    raw_chunks = splitter.split_text(text)

    # Simple section tracker: short lines with no terminal punctuation
    # (Wikipedia section titles are plain-text lines in the processed files)
    _section_title_re = re.compile(r"^[A-Z][^\n.!?]{2,80}$")
    cur_section = title

    chunks: list[dict] = []
    for c_idx, chunk_text in enumerate(raw_chunks):
        chunk_text = chunk_text.strip()
        if count_tokens(chunk_text) < 40:
            continue

        # Update section name if chunk starts with a short title-like line
        first_line = chunk_text.split("\n")[0].strip()
        if count_tokens(first_line) < 15 and _section_title_re.match(first_line):
            cur_section = first_line

        chunk_id = f"wikipedia_{sanitized_title}_s0_c{c_idx:02d}"
        chunks.append({
            "text": chunk_text,
            "contextualized_text": "",
            "metadata": {
                "chunk_id":    chunk_id,
                "source_file": f"wiki_{sanitized_title}.txt",
                "doc_type":    "wikipedia",
                "title":       title,
                "arxiv_id":    None,
                "authors":     [],
                "year":        None,
                "venue":       None,
                "hf_model_id": None,
                "language":    "en",
                "section":     cur_section,
                "subsection":  None,
                "page_start":  None,
                "chunk_index": c_idx,
                "token_count": count_tokens(chunk_text),
                "is_abstract": False,
                "has_math":    detect_has_math(chunk_text),
                "has_code":    detect_has_code(chunk_text),
                "has_table":   detect_has_table(chunk_text),
            },
        })

    return chunks


# ── Dispatcher ────────────────────────────────────────────────────────────────

def chunk_document(filepath: Path, doc_type: str, metadata: dict) -> list[dict]:
    if doc_type == "paper":
        return chunk_arxiv(filepath, metadata)
    elif doc_type == "model_card":
        return chunk_hf_model_card(filepath, metadata)
    elif doc_type == "wikipedia":
        return chunk_wikipedia(filepath, metadata["title"])
    raise ValueError(f"Unknown doc_type: {doc_type}")


# ── Main pipeline ─────────────────────────────────────────────────────────────

def run() -> None:
    CHUNKS_DIR.mkdir(parents=True, exist_ok=True)
    all_chunks: list[dict] = []

    print("\n=== Chunking arXiv papers ===")
    for arxiv_id in ARXIV_IDS:
        md_path   = MARKDOWN / f"arxiv_{arxiv_id}.md"
        meta_path = RAW / f"arxiv_{arxiv_id}.json"
        if not md_path.exists():
            print(f"  {arxiv_id}: markdown not found, skipping")
            continue
        doc_meta: dict = {"arxiv_id": arxiv_id, "title": arxiv_id}
        if meta_path.exists():
            try:
                doc_meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                pass
        chunks = chunk_document(md_path, "paper", doc_meta)
        print(f"  {arxiv_id}: {len(chunks)} chunks")
        all_chunks.extend(chunks)

    print("\n=== Chunking HuggingFace model cards ===")
    for model_id in HF_MODELS:
        sanitized = model_id.replace("/", "_")
        md_path = MARKDOWN / f"hf_{sanitized}.md"
        if not md_path.exists():
            print(f"  {model_id}: markdown not found, skipping")
            continue
        chunks = chunk_document(md_path, "model_card", {"hf_model_id": model_id})
        print(f"  {model_id}: {len(chunks)} chunks")
        all_chunks.extend(chunks)

    print("\n=== Chunking Wikipedia articles ===")
    for title in WIKI_ARTICLES:
        sanitized = re.sub(r"[^\w]+", "_", title).strip("_")
        md_path = MARKDOWN / f"wiki_{sanitized}.md"
        if not md_path.exists():
            print(f"  {title}: markdown not found, skipping")
            continue
        chunks = chunk_document(md_path, "wikipedia", {"title": title})
        print(f"  {title}: {len(chunks)} chunks")
        all_chunks.extend(chunks)

    # Re-index chunk_index globally across all docs (per the schema)
    for i, chunk in enumerate(all_chunks):
        chunk["metadata"]["chunk_index"] = i

    output_path = CHUNKS_DIR / "all_chunks.jsonl"
    with output_path.open("w", encoding="utf-8") as f:
        for chunk in all_chunks:
            f.write(json.dumps(chunk, ensure_ascii=False) + "\n")

    print(f"\nWrote {len(all_chunks)} chunks to {output_path}")
    _print_summary(all_chunks)


def _print_summary(chunks: list[dict]) -> None:
    from collections import Counter
    type_counts: Counter = Counter()
    token_counts: list[int] = []
    n_math = n_code = n_table = 0
    for c in chunks:
        m = c["metadata"]
        type_counts[m["doc_type"]] += 1
        token_counts.append(m["token_count"])
        if m["has_math"]:  n_math  += 1
        if m["has_code"]:  n_code  += 1
        if m["has_table"]: n_table += 1
    avg = sum(token_counts) / len(token_counts) if token_counts else 0
    print("\n=== Chunking Summary ===")
    print(f"Total chunks:           {len(chunks)}")
    for dt, cnt in sorted(type_counts.items()):
        print(f"  {dt:<22} {cnt}")
    print(f"Average token count:    {avg:.1f}")
    print(f"Min / Max token count:  {min(token_counts)} / {max(token_counts)}")
    print(f"has_math:               {n_math}")
    print(f"has_code:               {n_code}")
    print(f"has_table:              {n_table}")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    os.chdir(Path(__file__).parent.parent)
    print(f"Working directory: {Path.cwd()}")
    run()
    print("\n=== Phase 3 Complete ===")
