#!/bin/bash
# Download arXiv PDFs using wget

set -e
cd corpus/raw

PAPERS=(
    "2005.11401"
    "2004.04906"
    "2004.12832"
    "2112.01488"
    "2104.08663"
    "2112.09118"
    "2310.11511"
    "2401.18059"
    "2404.16130"
    "2407.01449"
    "2212.10496"
    "2210.07316"
    "2307.03172"
    "2407.12854"
    "2212.10511"
)

for id in "${PAPERS[@]}"; do
    dest="arxiv_${id}.pdf"
    if [ -f "$dest" ]; then
        echo "Already exists: $dest"
        continue
    fi
    echo "Downloading $id..."
    wget -q --user-agent="Mozilla/5.0" -O "$dest" "https://arxiv.org/pdf/${id}"
    sleep 2
done

echo "Done. Files in corpus/raw:"
ls -lh arxiv_*.pdf 2>/dev/null || echo "No PDFs found"
