import pymupdf
doc = pymupdf.open("corpus/raw/arxiv_2004.04906.pdf") # open a document

md_content = ""

for page in doc: # iterate the document pages
  text = page.get_text()
  md_content += text
  

with open("test_pymupdf.md", "w") as f:
    f.write(md_content)