'Dense Passage Retrieval for Open-Domain Question Answering
nVladimir Karpukhin∗, Barlas O˘guz∗, Sewon Min†, Patrick Lewis,
nLedell Wu, Sergey Edunov, Danqi Chen‡, Wen-tau Yih
nFacebook AI
n†University of Washington
n‡Princeton University
n{vladk, barlaso, plewis, ledell, edunov, scottyih}@fb.com
nsewon@cs.washington.edu
ndanqic@cs.princeton.edu
nAbstract
nOpen-domain question answering relies on ef-
nﬁcient passage retrieval to select candidate
ncontexts, where traditional sparse vector space
nmodels, such as TF-IDF or BM25, are the de
nfacto method.
nIn this work, we show that
nretrieval can be practically implemented us-
ning dense representations alone, where em-
nbeddings are learned from a small number
nof questions and passages by a simple dual-
nencoder framework.
nWhen evaluated on a
nwide range of open-domain QA datasets, our
ndense retriever outperforms a strong Lucene-
nBM25 system greatly by 9%-19% absolute in
nterms of top-20 passage retrieval accuracy, and
nhelps our end-to-end QA system establish new
nstate-of-the-art on multiple open-domain QA
nbenchmarks.1

n1

nIntroduction

nOpen-domain question answering (QA) (Voorhees,
n1999) is a task that answers factoid questions us-
ning a large collection of documents. While early
nQA systems are often complicated and consist of
nmultiple components (Ferrucci (2012); Moldovan
net al. (2003), inter alia), the advances of reading
ncomprehension models suggest a much simpliﬁed
ntwo-stage framework: (1) a context retriever ﬁrst
nselects a small subset of passages where some
nof them contain the answer to the question, and
nthen (2) a machine reader can thoroughly exam-
nine the retrieved contexts and identify the correct
nanswer (Chen et al., 2017). Although reducing
nopen-domain QA to machine reading is a very rea-
nsonable strategy, a huge performance degradation
nis often observed in practice2, indicating the needs
nof improving retrieval.
n∗Equal contribution
n1The code and trained models have been released at
nhttps://github.com/facebookresearch/DPR.
n2For instance, the exact match score on SQuAD v1.1 drops
nfrom above 80% to less than 40% (Yang et al., 2019a).
nRetrieval in open-domain QA is usually imple-
nmented using TF-IDF or BM25 (Robertson and
nZaragoza, 2009), which matches keywords efﬁ-
nciently with an inverted index and can be seen
nas representing the question and context in high-
ndimensional, sparse vectors (with weighting). Con-
nversely, the dense, latent semantic encoding is com-
nplementary to sparse representations by design. For
nexample, synonyms or paraphrases that consist of
ncompletely different tokens may still be mapped to
nvectors close to each other. Consider the question
n“Who is the bad guy in lord of the rings?”, which can
nbe answered from the context “Sala Baker is best
nknown for portraying the villain Sauron in the Lord
nof the Rings trilogy.” A term-based system would
nhave difﬁculty retrieving such a context, while
na dense retrieval system would be able to better
nmatch “bad guy” with “villain” and fetch the cor-
nrect context. Dense encodings are also learnable
nby adjusting the embedding functions, which pro-
nvides additional ﬂexibility to have a task-speciﬁc
nrepresentation. With special in-memory data struc-
ntures and indexing schemes, retrieval can be done
nefﬁciently using maximum inner product search
n(MIPS) algorithms (e.g., Shrivastava and Li (2014);
nGuo et al. (2016)).
nHowever, it is generally believed that learn-
ning a good dense vector representation needs a
nlarge number of labeled pairs of question and con-
ntexts. Dense retrieval methods have thus never
nbe shown to outperform TF-IDF/BM25 for open-
ndomain QA before ORQA (Lee et al., 2019), which
nproposes a sophisticated inverse cloze task (ICT)
nobjective, predicting the blocks that contain the
nmasked sentence, for additional pretraining. The
nquestion encoder and the reader model are then ﬁne-
ntuned using pairs of questions and answers jointly.
nAlthough ORQA successfully demonstrates that
ndense retrieval can outperform BM25, setting new
nstate-of-the-art results on multiple open-domain
narXiv:2004.04906v3 
[cs.CL
] 30 Sep 2020
n'