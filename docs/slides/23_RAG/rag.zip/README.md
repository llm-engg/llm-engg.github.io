# Sample code from RAG Module

This README provides instructions for setting up the environment and running the RAG pipeline on a sample corpus. The pipeline includes downloading a corpus of documents, processing them (chunking, metadata extraction, OCR), and exploring retrieval strategies.

System requirements:
- Python 3.8 or higher
- `uv` for dependency management (optional but recommended)
- pipelines will be faster with a GPU, but can also run on CPU (with longer processing times)
- **NOT tested on Colab**, but should work with minor adjustments and environment variables.



## Installing the dependencies

This project uses `uv` to manage dependencies. Installing dependencies using `pip` is also possible, but `uv` is recommended for faster installation.

```bash

uv pip install -r requirements.txt
```


## Creating the virtual environment

```bash
mkdir -p corpus/{chroma_db, chunks, eval, graph, images, indices, markdown, raw, retrieval, vectorstores}
```

## Downloading the corpus

- Downloaing the arxiv papers

```bash
bash pipeline/download_arxiv.sh
```

- Downloading the HF model cards, Wikipedia articles, and QASPER dataset

```bash
python pipeline/01_download.py
```

## Processing the corpus
- Chunking, metadata extraction, and OCR (if necessary)

```bash
python pipeline/02_ocr.py
```

## Exploring the RAG pipeline

- Chunking strategies and indexng the corpus in `notebooks/rag_01_chunking.ipynb` 

- Retrieval  in `notebooks/rag_02_retrieval.ipynb` 

- Evaluation of retrieved context in `notebooks/rag_04_evaluation.ipynb`

- Late interaction retrieval using ColBERT in `notebooks/rag_05_colbert.ipynb`






