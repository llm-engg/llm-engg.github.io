#!/usr/bin/env bash
# ============================================================================
# DEMO 4 - measure how much quality you lose as the model shrinks
# Needs: the FP16 model from demo 0, and the wikitext test text (see README).
# ============================================================================
set -e   # stop the whole script if any command fails

echo "== DEMO 4: quality (perplexity) vs model size =="

# All demos need to know where llama.cpp is. Set this once before running:
#   export LLAMA_CPP=~/llama.cpp
# ( [ -z "$X" ] is true when X is empty or has not been set at all. )
if [ -z "$LLAMA_CPP" ]; then
  echo "Please set LLAMA_CPP to your llama.cpp folder first:"
  echo "  example export LLAMA_CPP=~/llama.cpp"
  exit 1
fi
echo "Using llama.cpp at: $LLAMA_CPP"

# ---- Settings --------------------------------------------------------------
BIN=$LLAMA_CPP/build/bin     # the compiled llama.cpp programs
MODEL="${1:-model-f16.gguf}"      # the full-size model to start from
TEST_TEXT=wiki.test.raw      # the text used to measure quality
NGL=99                       # how many layers to run on the GPU (use 0 for CPU only)
CSV=results.csv              # where the numbers get saved

# [ ! -f "$MODEL" ] is true when the file does NOT exist (-f = "is a file", ! = "not").
if [ ! -f "$MODEL" ]; then
  echo "Model not found: $MODEL   (run ./00-convert.sh first)"
  exit 1
fi
if [ ! -f "$TEST_TEXT" ]; then
  echo "Test text not found: $TEST_TEXT   (get it with scripts/get-wikitext-2.sh, see README)"
  exit 1
fi

# Print a file's size in megabytes.
filesize() {
  du -m "$1" | cut -f1
}

# Run perplexity on one model and print just its final PPL number.
# The output has lines like "... PPL = 7.31 ...". The pipeline pulls that out:
#   grep -oE 'PPL = [0-9.]+'  = keep only the "PPL = 7.31" text
#   tail -1                   = take the last one
#   awk '{print $3}'          = print the 3rd word, the number itself
measure_ppl() {
  "$BIN/llama-perplexity" -m "$1" -f "$TEST_TEXT" -ngl "$NGL" 2>&1 \
    | grep -oE 'PPL = [0-9.]+' | tail -1 | awk '{print $3}'
}

# $( ... ) runs a command and drops its output right into the line.
# "| tee -a $CSV" both prints the line AND appends it to the CSV file.
echo "type,size_mb,ppl" > "$CSV"
echo "F16,$(filesize "$MODEL"),$(measure_ppl "$MODEL")" | tee -a "$CSV"

for type in Q8_0 Q4_K_M Q3_K_M IQ2_M; do
  out="model-$type.gguf"
  if [ ! -f "$out" ]; then
    "$BIN/llama-quantize" "$MODEL" "$out" "$type" > /dev/null 2>&1   # hide the long log
  fi
  echo "$type,$(filesize "$out"),$(measure_ppl "$out")" | tee -a "$CSV"
done

echo "-> saved the numbers to $CSV"
# Draw the graph if matplotlib is installed (plot_curve.py falls back to text).
python3 "$LLAMA_CPP/quant-demos/plot_curve.py" "$CSV" || echo "(plot skipped)"
