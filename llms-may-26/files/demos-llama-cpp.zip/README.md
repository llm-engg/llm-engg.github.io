# Inference Mechanics and Quantization using llama.cpp

## The list of demos

| Script | Demo |
|--------|-------------------|
|`llm-inference-mechanics.pynb` | A Jupyter notebook that shows how a transformer model generates text |
|`hf-checkpoint-internals-qwen3-4b.ipynb` | A Jupyter notebook that shows how a Hugging Face checkpoint is structured |
| `00-convert.sh` | How a Hugging Face model becomes a single GGUF file |
| `01-anatomy.sh` | A GGUF file holds the weights, the tokenizer, and the model settings all together |
| `02-quantize.sh` | Apply different quantization schemes to a GGUF model |
| `03-inside-kquant.sh` | A "4-bit" model like Q4_K_M isn't actually 4 bits everywhere, some layers use more bits |
| `04-ppl-curve.sh` | Measuring how much quality you lose as the model shrinks |
| `05-imatrix.sh` | Use calibration to make small quants (2-bit) stable |
| `06-bench.sh` | Why smaller models generate text faster |
| `infer.sh` | Actually talking to a quantized model, with `llama-cli` and `llama-server` |

Each script (.sh) is self-contained: it opens with a short `Settings` block of
constants you can read and edit, followed by the demo itself. 

## Setup Prerequisites

**NOTE** : The demos are designed to run on a local machine but can also be run on Google Colab. You can skip the python setup steps if you are running on Colab, as the environment is already set up for you. You need to install llama.cpp on Colab.

**We need a built copy of llama.cpp.** The demos call the `llama-quantize`,
`llama-perplexity`, `llama-bench`, `llama-imatrix`, `llama-cli`, and
`llama-server` programs. 

You can download pre-built binaries of llama.cpp, or build it yourself.

### Download pre-built llama.cpp binaries

Please see the [llama.cpp releases page](https://github.com/ggml-org/llama.cpp/releases) for pre-built binaries for your platform. Download the latest release and extract it to a folder of your choice.


### Build llama.cpp yourself

- Get the source code:
```bash
git clone https://github.com/ggml-org/llama.cpp.git
```

- Build it:

```bash
cd llama.cpp
cmake -B build
cmake --build build -j
```

**Build with CUDA if you have an NVIDIA GPU.** 

GPU support is chosen when you *configure* the build with CUDA turned on and rebuild:

```bash
cmake -B build -DGGML_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=<your-arch> -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

`CMAKE_CUDA_ARCHITECTURES` is your GPU's compute capability with the dot
removed, so `12.1` becomes `121`. Ask the card what it is:

```bash
nvidia-smi --query-gpu=name,compute_cap --format=csv
```

| GPU | compute_cap | Use |
|-----|-------------|-----|
| GB10 (DGX Spark), RTX 50xx | 12.1 / 12.0 | `121` / `120` |
| H100 | 9.0 | `90` |
| RTX 40xx | 8.9 | `89` |
| A100 | 8.0 | `80` |

You can leave `CMAKE_CUDA_ARCHITECTURES` out and llama.cpp will guess.
This needs the CUDA toolkit installed (`nvcc --version` should print something).

```bash
grep GGML_CUDA:BOOL build/CMakeCache.txt   # want: GGML_CUDA:BOOL=ON
```

**for other platforms** (Apple M series, AMD, Intel, etc.) ypu can build or download platform speicific version. 

- set up LLAMA_CPP environment variable
Every script needs to know where your llama.cpp folder is. Set `LLAMA_CPP` once, and it stays set for the rest of your terminal session:

```bash
export LLAMA_CPP=<path to your llama.cpp folder>
```

Each script prints the path it is using when it starts, and stops with a
reminder if the environment variable is not set.

- Install python packages

**Python packages.** Python notebooks and demos 0, 1, and 3 need few python packages. You can run them on colab with default packages, but if you want to run them locally, install the packages in a virtual environment:

```bash
# create a virtual environment with virtualenv or venv. 
python -m venv venv
source venv/bin/activate
pip install gguf torch matplotlib jupyterlab

```

**A model to work with.** You have two choices here. Either download one and
convert it (shown below), or point the demos at a GGUF file you already have.

## Setup the base GGUF model and test files

The scripts read their input files (`model-f16.gguf`, `wiki.test.raw`, `calibration.txt`) from the folder you run them in, and write their output there too. 

### Step 1: get a model and convert it to GGUF

Download a model from Hugging Face, then convert it to a full-size (FP16) GGUF
file. That FP16 file is the starting point for every demo.

```bash
# download the model files
hf download Qwen/Qwen3-4B-Instruct-2507 --local-dir ~/models/Qwen3-4B-Instruct-2507

# convert them into one FP16 GGUF named model-f16.gguf
HF_MODEL_DIR=~/models/Qwen3-4B-Instruct-2507 ./00-convert.sh
```

That writes `model-f16.gguf` into this folder.

If you already have an FP16 GGUF, skip the download and just copy it in under
the name the demos expect:

```bash
cp ~/models/some-model-f16.gguf model-f16.gguf
```

**Converting from an FP8 or FP4 model**

If your checkpoint is already quantized (not in BF16 or FP16), you can still convert it to GGUF.


FP8 works. If the model's `config.json` says it uses FP8 (the block-scaled kind that models like DeepSeek ship), the converter detects it and unpacks it back to FP16 for you. There's nothing extra to pass.

FP4 works only for some formats. NVFP4 and MXFP4 convert for the model families that have support (Llama, Qwen, Gemma, gpt-oss, DeepSeek). A plain FP4 file with no quantization info in its `config.json` will not convert.

Even when it works, converting from FP8 or FP4 is a poor fit for these demos.
The demos take a full-precision model, shrink it, and measure what you lose. If your starting point is already FP8, the top of the quality curve in demo 4 is not a true full-precision reference, so the quality-loss numbers are measured against something that was already lossy. When a normal BF16 or FP16 version of the model exists, download and convert that one instead.

### Step 2: get the test text (needed for demos 4 and 5)

Demo 4 measures quality using a standard dataset called wikitext. The llama.cpp repo has a script to download it. Run that script, then copy the test file into this folder:

```bash
"$LLAMA_CPP/scripts/get-wikitext-2.sh"
cp wikitext-2-raw/wiki.test.raw wiki.test.raw
```

### Step 3: get calibration text (needed for demo 5 only)

Demo 5 needs a second, different piece of text to calibrate the small quant. It has to be different from the test text in step 2, otherwise the measurement
cheats. Any few hundred KBs of normal text works:

```bash
head -c 400000 wikitext-2-raw/wiki.train.raw > calibration.txt
```

## Run inference on a GGUF model

**`infer.sh` (run inference on a GGUF model).** Use this script to run inference on a GGUF model. It takes the file to run as its first argument and how to run it as the second:

```bash
./infer.sh model-Q4_K_M.gguf          # ask one question, print the answer, exit
./infer.sh model-Q4_K_M.gguf chat     # keep talking to it
./infer.sh model-Q4_K_M.gguf server   # serve it over HTTP on port 8080
```

The first two use `llama-cli`, which loads the model, prints to your terminal,
and quits. The third uses `llama-server`, which stays running and answers HTTP
requests using the same API shape as OpenAI, so any client that can talk to
OpenAI can talk to it by pointing at `http://localhost:8080/v1`.

## Running the demos

Run them one at a time and read the output before moving on:

```bash
./01-anatomy.sh
./02-quantize.sh
./03-inside-kquant.sh
./04-ppl-curve.sh
./05-imatrix.sh
./06-bench.sh
```

The demos that need quantized files (3, 4, and 6) will make any that are
missing, so the first one you run does the quantizing and the rest reuse it.
Everything is saved in the current folder, so running a demo a second time is
quick.

To run all of them back to back:

```bash
./run-all.sh
```

## What each demo shows


**Demo 1 (anatomy).** Prints the quantization parameters stored inside the GGUF file: the model architecture, the tokenizer, the chat template. 

The one GGUF file is the whole model. There's no separate config or tokenizer file to keep track of.
    
**Demo 2 (quantize).** Prints a table of quant type and file size. Watch the
size drop as you go from the full FP16 model down through the smaller types.

**Demo 3 (inside a k-quant).** Prints a count of the data types used inside a
Q4_K_M model. Even though it's called "4-bit", you'll see some parts stored at
5 and 6 bits. The important weights get more precision

**Demo 4 (quality curve).** Runs perplexity on each model size, where lower is better. It saves the numbers to `results.csv` and, if you have matplotlib installed, draws `results.png`. Look for the point on the curve where quality suddenly drops off. 

**Demo 5 (calibration).** Makes the same 2-bit model twice, once with a
calibration step and once without, then compares their quality. The calibrated
one should be much better. This is why the very small quants need an imatrix calibration step: the model is so small that it can't store enough information to be stable on its own.

**Demo 6 (speed).** Benchmarks how many tokens per second each size can
generate. Smaller models generate faster. That's because due to inference being memory bottlenecked, generating text spends most of its time reading the model weights out of memory, so fewer bits means less to read.
    
**`infer.sh` (run inference on a GGUF model).** Use this script to run inference on a GGUF model. It takes the file to run as its first argument and how to run it as the second:

```bash
./infer.sh model-Q4_K_M.gguf          # ask one question, print the answer, exit
./infer.sh model-Q4_K_M.gguf chat     # keep talking to it
./infer.sh model-Q4_K_M.gguf server   # serve it over HTTP on port 8080
```

The first two use `llama-cli`, which loads the model, prints to your terminal,
and quits. The third uses `llama-server`, which stays running and answers HTTP
requests using the same API shape as OpenAI, so any client that can talk to
OpenAI can talk to it by pointing at `http://localhost:8080/v1`.

## Settings you can change

Each script starts with a short `Settings` block of plain constants. Open a
script, read that block, and change a value if you want to. For example, the
top of `06-bench.sh` looks like this:

```bash
# ---- Settings --------------------------------------------------------------
BIN=$LLAMA_CPP/build/bin     # the compiled llama.cpp programs
MODEL=model-f16.gguf         # the full-size model to start from
NGL=99                       # how many layers to run on the GPU (use 0 for CPU only)
```

| Setting | Default | What it does |
|---------|---------|--------------|
| `MODEL` | `model-f16.gguf` | The full-size model the demos start from |
| `NGL` | `99` | How many layers to run on the GPU. Set it to `0` if you have no GPU |

The quant types are written right into a `for` loop in demos 2, 4, and 6:

```bash
for type in Q8_0 Q4_K_M Q3_K_M IQ2_M; do
```

Edit that list to make a run shorter or to try other types. To see the full
list of quant types your build supports, run `$LLAMA_CPP/build/bin/llama-quantize` with no arguments. The list grows over time as new types get added.

## If something goes wrong

| Message | What to do |
|---------|------------|
| "Please set LLAMA_CPP" | Run `export LLAMA_CPP=~/llama.cpp` (point it at your llama.cpp folder) |
| "Model not found" | Run `00-convert.sh` first, or copy your FP16 GGUF in as `model-f16.gguf` |
| "gguf-dump tool is missing" | Install the gguf package for demos 1 and 3: `pip install gguf` |
| "Test text not found" | Get it with `$LLAMA_CPP/scripts/get-wikitext-2.sh` (see step 2) |
| "Calibration text not found" | Make a calibration file (see step 3) |
| "no usable GPU found, --gpu-layers option will be ignored" | Your llama.cpp was built without CUDA. Rebuild it with `-DGGML_CUDA=ON` (see "Build with CUDA" above) |
| GPU errors, or you have no GPU | Set `NGL=0` in the script's Settings block |
| Out of memory on the GPU, even with a small quant | The KV cache is separate from the weights and quantizing does not shrink it. Lower `-c` (context size) in `infer.sh`, or lower `NGL` so fewer layers sit on the GPU |
| It's taking too long | Shorten the quant list in the `for type in ...` loop |
| "Unknown quant type" | Run `$LLAMA_CPP/build/bin/llama-quantize` with no arguments to see the valid types |

## A note on files

The quantized models are large (several gigabytes each) and they get written
into whatever folder you run. 