#!/usr/bin/env bash
# ============================================================================
# talk to the model, two different ways

#   llama-cli     one process, prints to your terminal, exits. Good for a quick
#                 look, for scripting, and for pasting output into a demo.
#   llama-server  stays running and speaks the OpenAI HTTP API, so any client
#                 (curl, a browser, the openai python package) can talk to it.
#                 This is how you would actually deploy the thing.
#
# Both load the exact same file. Nothing about the model changes between them.
#
# How to run this demo:
#   ./infer.sh out/model-Q4_K_M.gguf          # one-shot answer in the terminal
#   ./infer.sh out/model-Q4_K_M.gguf chat     # keep talking to it
#   ./infer.sh out/model-Q4_K_M.gguf server   # start the HTTP server
#
# Try it on two quants from demo 2 and compare the answers - that is the whole
# point of quantizing, and it is easier to feel than to read off a table.
# ============================================================================
set -e   # stop the whole script if any command fails

# All demos need to know where llama.cpp is. Set this once before running:
#   export LLAMA_CPP=~/llama.cpp
# ( [ -z "$X" ] is true when X is empty or has not been set at all. )
if [ -z "$LLAMA_CPP" ]; then
  echo "Please set LLAMA_CPP to your llama.cpp folder first:"
  echo "  example export LLAMA_CPP=~/llama.cpp"
  exit 1
fi
echo "Using llama.cpp at: $LLAMA_CPP"

# ---- Settings --------------------------------------------------------------
BIN=$LLAMA_CPP/build/bin             # the compiled llama.cpp programs
MODEL="${1:-model-f16.gguf}"         # which GGUF to run (any quant works)
MODE="${2:-once}"                    # once | chat | server
NGL=99                               # layers to put on the GPU (0 = CPU only)
PORT=8080                            # port llama-server listens on
PROMPT="${PROMPT:-Explain what model quantization is, in two sentences.}"

# [ ! -f "$MODEL" ] is true when the file does NOT exist (-f = "is a file", ! = "not").
if [ ! -f "$MODEL" ]; then
  echo "Model not found: $MODEL   (run ./00-convert.sh, then ./02-quantize.sh)"
  echo "  example ./infer.sh out/model-Q4_K_M.gguf"
  exit 1
fi

echo "== running $MODEL ($MODE) =="

# "case" picks one branch by matching $MODE against each pattern before the ")".
case "$MODE" in

  # ---- llama-cli, one question and out -------------------------------------
  once)
    # -no-cnv  answer once and exit, instead of opening an interactive chat
    # -n 200   stop after 200 new tokens so the demo cannot run away
    # -ngl     how much of the model to hand to the GPU
    "$BIN/llama-cli" -m "$MODEL" -ngl "$NGL" -no-cnv -n 200 -p "$PROMPT"
    echo
    echo "That was llama-cli. Same command with a different -m is how you"
    echo "compare quants: run it on Q8_0 and on IQ2_M and read both answers."
    ;;

  # ---- llama-cli, interactive ----------------------------------------------
  chat)
    # Without -no-cnv, llama-cli applies the model's chat template and keeps
    # the conversation going. Ctrl-C when you are done.
    "$BIN/llama-cli" -m "$MODEL" -ngl "$NGL" \
      -sys "You are a concise, helpful assistant."
    ;;

  # ---- llama-server, an HTTP endpoint --------------------------------------
  server)
    echo "Starting the server. Leave this running and open a second terminal."
    echo
    echo "  web UI:   http://localhost:$PORT"
    echo
    echo "  from the shell:"
    echo "    curl -s http://localhost:$PORT/v1/chat/completions \\"
    echo "      -H 'Content-Type: application/json' \\"
    echo "      -d '{\"messages\":[{\"role\":\"user\",\"content\":\"hello\"}]}'"
    echo
    echo "The path is /v1/chat/completions because llama-server copies the"
    echo "OpenAI API on purpose: anything that talks to OpenAI talks to this,"
    echo "by pointing base_url at localhost. Ctrl-C to stop."
    echo

    # -c 4096  context window. Bigger costs memory for the KV cache, which is
    #          separate from the weights and is NOT shrunk by quantizing them.
    "$BIN/llama-server" -m "$MODEL" -ngl "$NGL" -c 4096 --port "$PORT"
    ;;

  *)
    echo "Unknown mode: $MODE   (use: once | chat | server)"
    exit 1
    ;;
esac
