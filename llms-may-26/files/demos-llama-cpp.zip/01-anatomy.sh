#!/usr/bin/env bash
# ============================================================================
# DEMO 1 - a GGUF file holds everything in one place

# Needs: the FP16 model from demo 0, and the gguf-dump tool (pip install gguf).

# How to run this demo:
# export LLAMA_CPP=/projects/llama.cpp
# Activate your Python environment (create one if you haven't already) and install the gguf package:
# pip install gguf
# Then run the demo with the GGUF file you created in demo 0, for example
# bash 01-anatomy.sh qwen3-4B-Instruct-f16.gguf
# ============================================================================
set -e   # stop the whole script if any command fails

echo "== DEMO 1: what is inside a GGUF file =="

# All demos need to know where llama.cpp is. Set this once before running:
#   export LLAMA_CPP=~/llama.cpp
# ( [ -z "$X" ] is true when X is empty or has not been set at all. )
if [ -z "$LLAMA_CPP" ]; then
  echo "Please set LLAMA_CPP to your llama.cpp folder first:"
  echo "  example export LLAMA_CPP=~/llama.cpp"
  exit 1
fi
echo "Using llama.cpp at: $LLAMA_CPP"

# ---- Settings --------------------------------------------------------------
# "${1:-model-f16.gguf}" means: use argument 1, or model-f16.gguf if none given.
MODEL="${1:-model-f16.gguf}"

# [ ! -f "$MODEL" ] is true when the file does NOT exist (-f = "is a file", ! = "not").
if [ ! -f "$MODEL" ]; then
  echo "Model not found: $MODEL   (run ./00-convert.sh first)"
  exit 1
fi
# command -v checks whether a program is installed.
if ! command -v gguf-dump > /dev/null; then
  echo "The gguf-dump tool is missing. Install it with:  pip install gguf"
  exit 1
fi

echo
echo "--- Settings stored in the file (architecture, tokenizer, chat template) ---"
gguf-dump --no-tensors "$MODEL" | head -n 60     # show only the first 60 lines

echo
echo "--- How many weight tensors the file holds ---"
gguf-dump "$MODEL" | grep -c weight              # count the lines that say "weight"
echo "^ weights, tokenizer, and settings are ALL in this one file."
