#!/usr/bin/env bash
# ============================================================================
# DEMO 2 - Apply different quantization schemes to a GGUF model
#
# Making a smaller model is a single call to llama-quantize.
# This makes a few sizes and prints a table so you can watch the file shrink.
#
# Needs: the FP16 model from demo 0. Pass its path as the last argument:
#   ./02-quantize.sh out/model-f16.gguf
# The quantized files are written next to it, e.g. out/model-Q4_K_M.gguf
# Leave the argument off and we look for ./model-f16.gguf.

# ============================================================================

set -e   # stop the whole script if any command fails

echo "== DEMO 2: quantize the model and watch the size drop =="

# All demos need to know where llama.cpp is. Set this once before running:
#   export LLAMA_CPP=~/llama.cpp
# ( [ -z "$X" ] is true when X is empty or has not been set at all. )
if [ -z "$LLAMA_CPP" ]; then
  echo "Please set LLAMA_CPP to your llama.cpp folder first:"
  echo "  example export LLAMA_CPP=~/llama.cpp"
  exit 1
fi
echo "Using llama.cpp at: $LLAMA_CPP"

# ---- Settings --------------------------------------------------------------
BIN=$LLAMA_CPP/build/bin              # the compiled llama.cpp programs
MODEL="${1:-model-f16.gguf}"          # the full-size model we shrink

# [ ! -f "$MODEL" ] is true when the file does NOT exist (-f = "is a file", ! = "not").
if [ ! -f "$MODEL" ]; then
  echo "Model not found: $MODEL   (run ./00-convert.sh first)"
  echo "  example ./02-quantize.sh out/model-f16.gguf"
  exit 1
fi

# Build the names for the files we are about to make, from the name we were given.
# For out/model-f16.gguf this gives OUT_DIR=out and PREFIX=model,
# so the quants land beside the original as out/model-Q4_K_M.gguf and friends.
#   dirname  = the folder part of a path
#   basename = the file part, and the second argument strips that ending
OUT_DIR="$(dirname "$MODEL")"
PREFIX="$(basename "$MODEL" .gguf)"
PREFIX="${PREFIX%-f16}"

# Print a file's size in megabytes.
filesize() {
  du -m "$1" | cut -f1
}

# printf prints a row: %-10s = text in a left-aligned 10-wide column,
# %8s = text in a right-aligned 8-wide column, \n = end the line.
printf "%-10s %8s\n" "TYPE" "SIZE_MB"
printf "%-10s %8s\n" "F16" "$(filesize "$MODEL")"

# Try a few quant types, from biggest/best to smallest. Run llama-quantize
# with no arguments to see every type your build supports.
for type in Q8_0 Q4_K_M Q3_K_M; do
  out="$OUT_DIR/$PREFIX-$type.gguf"
  if [ ! -f "$out" ]; then
    # Make this quant. 
    echo "$BIN/llama-quantize" "$MODEL" "$out" "$type"
    "$BIN/llama-quantize" "$MODEL" "$out" "$type"
  fi
  printf "%-10s %8s\n" "$type" "$(filesize "$out")"
done
