#!/usr/bin/env bash
# ============================================================================
# DEMO 6 - smaller models generate text faster
#
# Teaching point: generating text spends most of its time reading the model
# weights out of memory. Fewer bits means less to read, so smaller quants run
# faster. llama-bench reports tokens per second for each size.
#
# Needs: the FP16 model from demo 0.
# ============================================================================
set -e   # stop the whole script if any command fails

echo "== DEMO 6: generation speed vs model size =="

# All demos need to know where llama.cpp is. Set this once before running:
#   export LLAMA_CPP=~/llama.cpp
# ( [ -z "$X" ] is true when X is empty or has not been set at all. )
if [ -z "$LLAMA_CPP" ]; then
  echo "Please set LLAMA_CPP to your llama.cpp folder first:"
  echo "  example export LLAMA_CPP=~/llama.cpp"
  exit 1
fi
echo "Using llama.cpp at: $LLAMA_CPP"

# ---- Settings --------------------------------------------------------------
BIN=$LLAMA_CPP/build/bin     # the compiled llama.cpp programs
MODEL="${1:-model-f16.gguf}"  # the full-size model to start from
NGL=99                       # how many layers to run on the GPU (use 0 for CPU only)

# [ ! -f "$MODEL" ] is true when the file does NOT exist (-f = "is a file", ! = "not").
if [ ! -f "$MODEL" ]; then
  echo "Model not found: $MODEL   (run ./00-convert.sh first)"
  exit 1
fi


# Benchmark the baseline and every quant together in one table.
# Each "-m <file>" adds one more model to the comparison.
"$BIN/llama-bench" -ngl "$NGL" -o md \
  -m "$MODEL" \
  -m Qwen3-4B-Instruct-2507-UD-IQ2_M.gguf \
  -m model-IQ2_M-imat.gguf

echo "^ compare the 'tg' (text-generation) column: it rises as the bits fall."
