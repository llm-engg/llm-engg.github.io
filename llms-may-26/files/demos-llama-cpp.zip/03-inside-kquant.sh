#!/usr/bin/env bash
# ============================================================================
# DEMO 3 - a "4-bit" model isn't actually 4 bits everywhere
#
# Q4_K_M is a recipe, not a single precision. The important
# tensors get stored at 5 or 6 bits
# Needs: the FP16 model from demo 0, and the gguf-dump tool (pip install gguf).
# ============================================================================
set -e   # stop the whole script if any command fails

echo "== DEMO 3: what is really inside a Q4_K_M model =="

# All demos need to know where llama.cpp is. Set this once before running:
#   export LLAMA_CPP=~/llama.cpp
# ( [ -z "$X" ] is true when X is empty or has not been set at all. )
if [ -z "$LLAMA_CPP" ]; then
  echo "Please set LLAMA_CPP to your llama.cpp folder first:"
  echo "  example export LLAMA_CPP=~/llama.cpp"
  exit 1
fi
echo "Using llama.cpp at: $LLAMA_CPP"

# ---- Settings --------------------------------------------------------------
BIN=$LLAMA_CPP/build/bin     # the compiled llama.cpp programs
MODEL="${1:-model-f16.gguf}"  # the full-size model to start from

if [ ! -f "$MODEL" ]; then
  echo "Model not found: $MODEL   (run ./00-convert.sh first)"
  exit 1
fi
# command -v checks whether a program is installed.
if ! command -v gguf-dump > /dev/null; then
  echo "The gguf-dump tool is missing. Install it with:  pip install gguf"
  exit 1
fi

# Build the Q4_K_M model if we don't have it yet.
kquant="${2:-model-Q4_K_M.gguf}"
if [ ! -f "$kquant" ]; then
  # "> /dev/null 2>&1" throws away the long log that llama-quantize prints.
  "$BIN/llama-quantize" "$MODEL" "$kquant" Q4_K_M > /dev/null 2>&1
fi

echo
echo "Count of each data type used inside this '4-bit' model:"
# This line reads: pull the type name (like Q4_K, Q6_K, F32) out of each tensor
# line, then sort them and count how many of each there are.
#   grep -oE '...'  = print just the matching type names
#   sort | uniq -c  = group identical names and count them
#   sort -rn        = show the most common first
gguf-dump "$kquant" | grep -oE 'Q[0-9]+_[A-Z0-9]*|IQ[0-9]+_[A-Z0-9]+|F16|F32' | sort | uniq -c | sort -rn
echo "^ notice the Q5_K / Q6_K rows: the important weights get more bits."
