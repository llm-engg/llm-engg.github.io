#!/usr/bin/env bash
# ============================================================================
# DEMO 5 - why tiny (2-bit) quants need a calibration step
#
# At 2-bit there aren't enough bits to store every weight well.
# An "importance matrix" (imatrix) figures out which weights matter most so the
# bits get spent on them. IQ2_M requires an imatrix, so we compare it with a
# similarly sized Q2_K quant that does not require calibration.
#
# Needs: the FP16 model from demo 0, calibration text, and the test text.
# The two texts must be DIFFERENT, or the measurement cheats.
# ============================================================================

set -euo pipefail   # stop the whole script if any command fails

echo "== DEMO 5: low-bit quantization with vs without calibration =="

# All demos need to know where llama.cpp is. Set this once before running:
#   export LLAMA_CPP=~/llama.cpp
# ( [ -z "$X" ] is true when X is empty or has not been set at all. )
if [ -z "${LLAMA_CPP:-}" ]; then
  echo "Please set LLAMA_CPP to your llama.cpp folder first:"
  echo "  example export LLAMA_CPP=~/llama.cpp"
  exit 1
fi
echo "Using llama.cpp at: $LLAMA_CPP"

# ---- Settings --------------------------------------------------------------
BIN="$LLAMA_CPP/build/bin"     # the compiled llama.cpp programs
MODEL="${1:-model-f16.gguf}"  # the full-size model to start from
CALIB_TEXT=calibration.txt   # text used to build the imatrix
TEST_TEXT=wiki.test.raw      # text used to measure quality
NGL=99                       # how many layers to run on the GPU (use 0 for CPU only)
IMATRIX=imatrix.gguf
PLAIN_MODEL=model-Q2_K-plain.gguf
IMATRIX_MODEL=model-IQ2_M-imat.gguf

# [ ! -f "$MODEL" ] is true when the file does NOT exist (-f = "is a file", ! = "not").
if [ ! -f "$MODEL" ]; then
  echo "Model not found: $MODEL   (run ./00-convert.sh first)"
  exit 1
fi
if [ ! -f "$CALIB_TEXT" ]; then
  echo "Calibration text not found: $CALIB_TEXT   (see README)"
  exit 1
fi
if [ ! -f "$TEST_TEXT" ]; then
  echo "Test text not found: $TEST_TEXT   (see README)"
  exit 1
fi
if cmp -s "$CALIB_TEXT" "$TEST_TEXT"; then
  echo "Calibration and test text must be different files."
  exit 1
fi
for program in llama-imatrix llama-quantize llama-perplexity; do
  if [ ! -x "$BIN/$program" ]; then
    echo "Required program not found: $BIN/$program"
    echo "Build llama.cpp first (see README)."
    exit 1
  fi
done

# Run perplexity on one model and print just its final PPL number.
# (grep keeps the "PPL = 7.31" text, tail takes the last, awk prints the number.)
measure_ppl() {
  "$BIN/llama-perplexity" -m "$1" -f "$TEST_TEXT" -ngl "$NGL" 2>&1 \
    | grep -oE 'PPL = [0-9.]+' | tail -1 | awk '{print $3}'
}

# Step 1: build the importance matrix from the calibration text.
if [ ! -f "$IMATRIX" ]; then
  "$BIN/llama-imatrix" -m "$MODEL" -f "$CALIB_TEXT" -o "$IMATRIX" -ngl "$NGL"
fi

# Step 2: make two low-bit quants. Q2_K is the uncalibrated baseline; IQ2_M
# uses the imatrix and is slightly smaller in bits per weight.
if [ ! -f "$PLAIN_MODEL" ]; then
  "$BIN/llama-quantize" "$MODEL" "$PLAIN_MODEL" Q2_K
fi
if [ ! -f "$IMATRIX_MODEL" ]; then
  "$BIN/llama-quantize" --imatrix "$IMATRIX" "$MODEL" "$IMATRIX_MODEL" IQ2_M
fi

# Step 3: measure both and compare.
plain_ppl=$(measure_ppl "$PLAIN_MODEL")
imatrix_ppl=$(measure_ppl "$IMATRIX_MODEL")

echo
echo "Q2_K without calibration: PPL = $plain_ppl"
echo "IQ2_M with calibration:   PPL = $imatrix_ppl"
echo "^ lower PPL is better; IQ2_M should retain more quality at a similar size."
