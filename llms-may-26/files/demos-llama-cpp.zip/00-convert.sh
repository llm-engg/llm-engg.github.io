#!/usr/bin/env bash

# DEMO 0 - turn a Hugging Face model into one FP16 GGUF file

# How to run this demo:
#   0. set LLAMA_CPP to your llama.cpp folder, for example:
#      export LLAMA_CPP=~/llama.cpp
#   1. Download a Hugging Face model to your local disk (see README.md)
#   2. Set HF_MODEL_DIR to the downloaded model folder, for example:
#        HF_MODEL_DIR=~/models/Meta-Llama-3-8B ./00-convert.sh out/model-f16.gguf
#   3. The script will create a single GGUF file with FP16 weights, ready for inference with llama.cpp.

# export LLAMA_CPP=/projects/llama.cpp
# export HF_MODEL_DIR=/projects/models/Meta-Llama-3-8B
# bash 00-convert.sh gpt-oss-20b.gguf


set -e   # stop the whole script if any command fails

echo "== DEMO 0: convert a Hugging Face model to an FP16 GGUF =="

# All demos need to know where llama.cpp is. Set this once before running:
#   export LLAMA_CPP=~/llama.cpp
# ( [ -z "$X" ] is true when X is empty or has not been set at all. )

if [ -z "$LLAMA_CPP" ]; then
  echo "Please set LLAMA_CPP to your llama.cpp folder first:"
  echo "  example export LLAMA_CPP=~/llama.cpp"
  exit 1
fi

echo "Using llama.cpp at: $LLAMA_CPP"


# The last thing you type on the command line is the file we create.
# "${1:-model-f16.gguf}" means: use argument 1, or model-f16.gguf if none given.
MODEL="${1:-model-f16.gguf}"

if [ -z "$HF_MODEL_DIR" ]; then
  echo "Set HF_MODEL_DIR to the downloaded model folder, for example:"
  echo "  HF_MODEL_DIR=~/models/Meta-Llama-3-8B ./00-convert.sh out/model-f16.gguf"
  exit 1
fi

# If the output lives in a folder that does not exist yet, create it, otherwise
# the converter fails at the very end after doing all the slow work.
mkdir -p "$(dirname "$MODEL")"

python3 "$LLAMA_CPP/convert_hf_to_gguf.py" "$HF_MODEL_DIR" --outfile "$MODEL" --outtype f16

echo "Done. Baseline model: $MODEL"

echo "You can run inference using gguf checkpoint with llama.cpp, for example:"
