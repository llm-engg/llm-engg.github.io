# vLLM Demos — Inference Servers Module


| # | Demo | Slide concept | Script | Client |
|---|------|---------------|--------|--------|
| 0 | KV Cache | KV caching accounting |  |  |
| 1 | Continuous batching, live | Static vs continuous batching | `serve.sh` | `client_continuous_batching.py` |
| 2 | KV-cache pool sizing | `--gpu-memory-utilization` / paging | `compare_kv_pool.sh` | — |
| 3 | FP8 KV cache | per-token KV formula (`dtype_bytes`) | `compare_kv_pool.sh` | — |
| 4 | Prefix caching TTFT | Prefix caching / RadixAttention | `serve.sh` | `benchmark_prefix_caching.py` |
| 5 | Chunked prefill | Chunked prefill / TTFT-vs-ITL fairness | `serve.sh --max-num-batched-tokens` | `client_chunked_prefill.py` |


Example Demo Run

>
> ```bash
> ./serve.sh  # Terminal A, wait for "Application startup complete" printed by vLLM
> ./watch_metrics.sh  # Terminal B
> python client_continuous_batching.py   # Terminal C
> ```

---

## 0. Setup 

**Environment.** 

- Create a venv and install required packages:

 ```bash
 python -m venv vllm-venv
 source vllm-venv/bin/activate
 pip install vllm openai
 ```

**Models.** All demo models are pre-downloaded in `~/.cache/huggingface` (`hf download <model>`). Scripts set `HF_HUB_OFFLINE=1` to avoid mid-demo network stalls; when downloading a model for the first time, prefix with
`HF_OFFLINE=0`.

**Client deps.** The Python clients only need `openai`:
`python client_xxx.py` works out of the box, or `pip install openai` in any env.

## Demo 1 : Continuous batching, live

*Slides: "Continuous Batching Mechanics"*

```bash
# Terminal A
./serve.sh # Qwen3-0.6B with DEBUG logging

# Terminal B
./watch_metrics.sh

# Terminal C
python client_continuous_batching.py
```

The client sends 8 staggered requests with output lengths
`[512, 32, 256, 32, 384, 48, 128, 32]` (`ignore_eos` makes lengths exact) and prints an event log plus a final ASCII timeline.

**What to observe:**
- Short bars end *inside* the span of long bars denote early exit. Under static  batching every request would end when the 512-token one ends.
- Requests launched later join the running batch immediately. `running=` in the metrics climbs without any "batch boundary".
- In the server DEBUG log: the periodic `Running: N reqs, Waiting: M reqs, GPU KV cache usage: X%` line.

---

## Demo 2 : KV-cache pool sizing

*Slides: "Key Config Options" (`--gpu-memory-utilization`), "Memory: Model Parameters + KV Cache + Activations".*

```bash
./compare_kv_pool.sh  # gpu-util 0.5 vs 0.9, no client needed
```

Prints the startup lines `GPU KV cache size: N tokens` and
`Maximum concurrency for L tokens per request: Cx` for both configs.

Weights are a fixed cost, so the *entire* difference in
memory budget lands in the KV pool → max concurrency scales with it. 

---

## Demo 3 : FP8 KV cache

*Slides: "KV Cache with Attention Variants" (per-token formula
`2 × layers × kv_heads × d_head × dtype_bytes`).*

```bash
ARGS_A="--gpu-memory-utilization 0.5" \
ARGS_B="--gpu-memory-utilization 0.5 --kv-cache-dtype fp8" \
./compare_kv_pool.sh
```
Same memory budget, but `dtype_bytes` drops 2 → 1, so
the pool holds ~2× the tokens. 

The KV formula's last factor is a *runtime knob*, not just architecture. (Quality caveat: FP8 KV is usually fine, use specific KV quantization schemes (KIVI, TurboQuant, etc.) for quantizing KV cache)

---

## Demo 4 : Prefix caching TTFT

*Slides: "Prefix Caching"

```bash
# Terminal A : any model; prefix caching is on by default (serve.sh passes it explicitly)
MODEL=Qwen/Qwen3-4B-Instruct-2507 ./serve.sh

# Terminal B
./watch_metrics.sh # watch prefix_cache_queries / hits climb

# Terminal C

MODEL_ID=Qwen/Qwen3-4B-Instruct-2507  python benchmark_prefix_caching.py --experiment system_prompt
```

Experiments available: `system_prompt`, `multi_turn`, `rag`, `cold_vs_warm` (or `all`). Each prints COLD vs WARM TTFT per request and a speedup summary.

**The first request pays a full prefill of the ~600-token
system prompt; every later request's TTFT collapses because those KV blocks are content-hashed and reused. `multi_turn` is the strongest story: TTFT stays ~flat while the prompt grows every turn.

---

## Demo 5 - Benchmark methodology (TTFT / TPOT / ITL / goodput)

*Slides: slides-3 "Is Throughput the Right Metric?" / "Benchmarking Methodology".*

```bash
# Against ANY running server:
./bench.sh  # the standard workload: 1024 in / 256 out, # 24 prompts, concurrency 4
                                 
CONCURRENCY=16 ./bench.sh # then increase concurrency and compare
```

As concurrency rises, aggregate throughput climbs while
per-stream TPOT/ITL degrade- throughput and goodput diverge. Also: median vs mean vs P99 TTFT (the burst at t=0 plus warmup skews the mean; steady state is the median).

---

## Demo 6 - MoE vs dense

*Slides: "vLLM Model support" (MoE).*

- Running a dense model and bench

```bash
vllm serve unsloth/Qwen3.6-27B-NVFP4 \
    --host 0.0.0.0 \
    --port 8000 \
    --tensor-parallel-size 1 \
    --trust-remote-code \
    --quantization modelopt \
    --kv-cache-dtype fp8 \
    --attention-backend flashinfer \
    --moe-backend marlin \
    --gpu-memory-utilization 0.4 \
    --max-model-len 262144 \
    --max-num-seqs 4 \
    --max-num-batched-tokens 8192 \
    --enable-chunked-prefill \
    --async-scheduling \
    --enable-prefix-caching \
    --load-format fastsafetensors 


# Run benchmark

bash ./bench.sh

```

- Running a MoE model and bench


```bash
vllm serve nvidia/Qwen3.6-35B-A3B-NVFP4 \
    --host 0.0.0.0 \
    --port 8000 \
    --tensor-parallel-size 1 \
    --trust-remote-code \
    --quantization modelopt \
    --kv-cache-dtype fp8 \
    --attention-backend flashinfer \
    --moe-backend marlin \
    --gpu-memory-utilization 0.4 \
    --max-model-len 262144 \
    --max-num-seqs 4 \
    --max-num-batched-tokens 8192 \
    --enable-chunked-prefill \
    --async-scheduling \
    --enable-prefix-caching \
    --skip-mm-profiling \
    --load-format fastsafetensors

# Run benchmark
bash ./bench.sh

```

The 35B (total) MoE decodes *faster* than the dense 27B because decode cost tracks **active** parameters (~3B).

> Sequencing: stop one server fully before starting the other 


 ## Demo 7: Use Codex or Claude code with model deployed on vLLM server

The instructions below show how to use Codex. For claude code please lookup instructions. 


- Run the model on vLLM server

```bash
vllm serve nvidia/Qwen3.6-35B-A3B-NVFP4 \
    --host 0.0.0.0 \
    --port 8000 \
    --tensor-parallel-size 1 \
    --trust-remote-code \
    --quantization modelopt \
    --kv-cache-dtype fp8 \
    --attention-backend flashinfer \
    --moe-backend marlin \
    --gpu-memory-utilization 0.4 \
    --max-model-len 262144 \
    --max-num-seqs 4 \
    --max-num-batched-tokens 8192 \
    --enable-chunked-prefill \
    --async-scheduling \
    --enable-prefix-caching \
    --skip-mm-profiling \
    --speculative-config '{"method":"mtp","num_speculative_tokens":3,"moe_backend":"triton"}' \
    --load-format fastsafetensors \
    --chat-template qwen3_codex_chat_template.jinja \ # needed for codex to work with vLLM server using new responses API
    --enable-auto-tool-choice \
    --tool-call-parser qwen3_coder \
    --default-chat-template-kwargs '{"enable_thinking": false}' \

```

- Edit codex config (~/.codex/config.toml) as below

```toml

# set model to the vLLM model you want to use, and set the model provider to vllm

#model = "unsloth/Qwen3.6-27B-NVFP4"
model = "nvidia/Qwen3.6-35B-A3B-NVFP4"
model_provider = "vllm"

[model_providers.vllm]
name = "vLLM"
env_key = "VLLM_API_KEY"
base_url = "http://localhost:8000/v1"
wire_api = "responses"

personality = "pragmatic"


[tui]
status_line = ["model-with-reasoning", "current-dir", "context-remaining", "used-tokens", "total-input-tokens", "total-output-tokens"]

# You can remove this line to use the default theme, or set it to any of the themes listed in the Codex documentation.
theme = "solarized-dark"

[tui.model_availability_nux]
"gpt-5.5" = 4
"gpt-5.6-sol" = 4

[features]
memories = true


# Your MCP servers go here

# Web search for the local vLLM models (Codex's built-in web_search tool only works
# against OpenAI's hosted API, so we provide search+fetch via MCP instead).
[mcp_servers.websearch]
command = "uvx"
args = ["duckduckgo-mcp-server"]

[mcp_servers.fetch]
command = "uvx"
args = ["mcp-server-fetch"]

```

- Run codex

```bash
export VLLM_API_KEY="dummy" # any value works, just needs to be set

# run codex
codex

```

## Troubleshooting

| Symptom | Fix |
|---|---|
| `ABORT: port 8000 already in use` | A server is still up: `ss -tlnp \| grep :8000`, stop it (Ctrl-C / `docker ps`). |
| `ABORT: only NG RAM available` | Previous run leaking: check `ps aux --sort=-rss \| head`, `ls -la /dev/shm`; reboot reclaims leaked shmem. |
| Server hangs at startup on a new model | First-launch compile/JIT — wait; watch the log. |
| `Cannot reach vLLM server` from a client | Server not finished loading — wait for `Application startup complete` in the log. |
| Model download attempted mid-demo | Model not fully cached: `HF_OFFLINE=0 ./serve.sh` once, or `hf download <model>` beforehand. |
