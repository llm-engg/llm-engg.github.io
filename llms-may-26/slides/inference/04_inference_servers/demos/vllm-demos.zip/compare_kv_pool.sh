#!/usr/bin/env bash
# =============================================================================
# compare_kv_pool.sh — launch the same model twice with different flags and
# diff the KV-cache pool that vLLM reports at startup.
#
# vLLM sizes its KV pool as:  (gpu_util x total memory) - weights - activations
# and logs the result as "GPU KV cache size: N tokens" plus
# "Maximum concurrency for L tokens per request: Cx".
# This script extracts exactly those lines for two configs, then shuts the
# server down — no client traffic needed.
#
# Usage:
#   ./compare_kv_pool.sh
#       default comparison: --gpu-memory-utilization 0.5  vs  0.9
#
#   ARGS_A="" ARGS_B="--kv-cache-dtype fp8" ./compare_kv_pool.sh
#       FP8 KV cache: dtype_bytes halves => pool tokens ~double
#       (per-token KV = 2 x layers x kv_heads x head_dim x dtype_bytes)
#
#   ARGS_A="--block-size 16" ARGS_B="--block-size 32" ./compare_kv_pool.sh
#       page-size effect (small)
#
# Env knobs: MODEL (default Qwen/Qwen3-0.6B), PORT, MAX_LEN, TIMEOUT (s)
# =============================================================================
set -euo pipefail

MODEL=${MODEL:-Qwen/Qwen3-0.6B}
PORT=${PORT:-8000}
MAX_LEN=${MAX_LEN:-16384}
TIMEOUT=${TIMEOUT:-600}
VLLM_BIN=${VLLM_BIN:-/projects/vllm/bin/vllm}
command -v "$VLLM_BIN" >/dev/null 2>&1 || VLLM_BIN=vllm

ARGS_A=${ARGS_A:---gpu-memory-utilization 0.5}
ARGS_B=${ARGS_B:---gpu-memory-utilization 0.9}

export HF_HUB_OFFLINE=${HF_OFFLINE:-1}
export TRANSFORMERS_OFFLINE=${HF_OFFLINE:-1}
export VLLM_NO_USAGE_STATS=1
export DO_NOT_TRACK=1

if ss -tln 2>/dev/null | grep -q ":$PORT "; then
  echo "ABORT: port $PORT already in use — stop the running server first."
  exit 1
fi

run_once() {
  local label=$1; shift
  local log
  log=$(mktemp /tmp/kv_pool_XXXX.log)
  echo
  echo "=== [$label] vllm serve $MODEL $* ==="
  echo "    (loading — takes a minute; log: $log)"
  # shellcheck disable=SC2068
  "$VLLM_BIN" serve "$MODEL" --port "$PORT" --max-model-len "$MAX_LEN" $@ \
      >"$log" 2>&1 &
  local pid=$!
  local waited=0
  until grep -q "Maximum concurrency" "$log"; do
    if ! kill -0 "$pid" 2>/dev/null; then
      echo "[$label] server exited early — last log lines:"
      tail -20 "$log"
      exit 1
    fi
    waited=$((waited + 1))
    if [ "$waited" -gt "$TIMEOUT" ]; then
      echo "[$label] timed out after ${TIMEOUT}s"
      kill -TERM "$pid" 2>/dev/null
      exit 1
    fi
    sleep 1
  done
  grep -E "KV cache size|Maximum concurrency" "$log" | sed "s/^/[$label] /"
  kill -TERM "$pid" 2>/dev/null
  wait "$pid" 2>/dev/null || true
  # Unified memory needs a moment to actually free before the next launch
  sleep 8
}

# Intentionally unquoted: ARGS_* hold multiple flags
run_once A $ARGS_A
run_once B $ARGS_B

echo
echo "Done. Compare the '[A]' vs '[B]' token counts above."
echo "Talking point: weights are fixed, so every extra GB of budget (or every"
echo "halving of KV dtype) goes straight into KV-pool tokens = more concurrent"
echo "requests the scheduler can admit."
