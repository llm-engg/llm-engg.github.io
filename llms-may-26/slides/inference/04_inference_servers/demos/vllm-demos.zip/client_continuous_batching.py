"""
client_continuous_batching.py
=============================
Makes continuous batching VISIBLE: sends staggered requests with wildly
different output lengths and prints a live event log + final timeline.

What to look for:
  * short requests START while long ones are still decoding (they join the
    running batch mid-flight — no waiting for a "batch boundary")
  * short requests FINISH and leave immediately (early exit — with static
    batching they would wait for the longest request in the batch)
  * the [metrics] lines show running/waiting counts changing token-by-token

Run next to the server log (serve.sh) and/or watch_metrics.sh.

Prerequisites: pip install openai   (already in /projects/vllm venv)

Usage:
    python client_continuous_batching.py
    python client_continuous_batching.py --num-requests 12 --stagger 1.0
    python client_continuous_batching.py --base-url http://localhost:8000
"""

import argparse
import asyncio
import re
import time
import urllib.request

from openai import AsyncOpenAI

# Mixed output lengths: long / short / medium interleaved.
# ignore_eos=True makes each request generate EXACTLY max_tokens, so the
# timeline is deterministic and the "short exits early" effect is guaranteed.
MAX_TOKENS_PATTERN = [512, 32, 256, 32, 384, 48, 128, 32]

PROMPT_TOPICS = [
    "the history of operating systems",
    "how virtual memory works",
    "the difference between throughput and latency",
    "why GPUs are good at matrix multiplication",
    "how a hash table works",
    "the CAP theorem",
    "how DNS resolves a domain name",
    "what a compiler does",
    "how TCP congestion control works",
    "what a B-tree index is",
    "how public key cryptography works",
    "what containers are and how they differ from VMs",
]


def sample_metrics(port: int):
    """Return (running, waiting) parsed from the /metrics endpoint."""
    try:
        with urllib.request.urlopen(
            f"http://localhost:{port}/metrics", timeout=1
        ) as resp:
            text = resp.read().decode()
    except Exception:
        return None

    def gauge(name: str) -> float:
        total = 0.0
        found = False
        for m in re.finditer(
            rf"^vllm:{name}(?:{{[^}}]*}})?\s+([0-9.eE+-]+)$", text, re.MULTILINE
        ):
            total += float(m.group(1))
            found = True
        return total if found else -1.0

    return gauge("num_requests_running"), gauge("num_requests_waiting")


async def metrics_watcher(port: int, t0: float, stop: asyncio.Event):
    """Print running/waiting whenever they change."""
    last = None
    while not stop.is_set():
        cur = await asyncio.to_thread(sample_metrics, port)
        if cur is not None and cur != last:
            r, w = cur
            print(f"  [{time.perf_counter() - t0:6.1f}s] [metrics] "
                  f"running={r:.0f} waiting={w:.0f}")
            last = cur
        try:
            await asyncio.wait_for(stop.wait(), timeout=1.0)
        except asyncio.TimeoutError:
            pass


async def one_request(client, model, idx, max_tokens, t0, results):
    topic = PROMPT_TOPICS[idx % len(PROMPT_TOPICS)]
    start = time.perf_counter() - t0
    print(f"  [{start:6.1f}s] START r{idx:<2d} (max_tokens={max_tokens})")

    ttft = None
    stream = await client.completions.create(
        model=model,
        prompt=f"Write a detailed explanation of {topic}:",
        max_tokens=max_tokens,
        temperature=0.7,
        stream=True,
        extra_body={"ignore_eos": True},
    )
    async for chunk in stream:
        if ttft is None:
            ttft = time.perf_counter() - t0 - start

    end = time.perf_counter() - t0
    print(f"  [{end:6.1f}s] DONE  r{idx:<2d} ({max_tokens} tok in "
          f"{end - start:.1f}s, ttft={ttft:.2f}s)")
    results[idx] = (start, end, max_tokens)


def print_timeline(results: dict):
    """ASCII Gantt chart: one bar per request, time on the x-axis."""
    if not results:
        return
    t_max = max(end for _, end, _ in results.values())
    width = 64
    print("\nTimeline (each bar = one request in the continuously-running batch):\n")
    for idx in sorted(results):
        start, end, max_tokens = results[idx]
        lead = int(start / t_max * width)
        bar = max(1, int((end - start) / t_max * width))
        print(f"  r{idx:<2d} {' ' * lead}{'█' * bar}  "
              f"{start:5.1f}s → {end:5.1f}s  ({max_tokens} tok)")
    print(f"\n  0s{' ' * (width - 2)}{t_max:.0f}s")
    print(
        "  * Short bars end early INSIDE the span of long bars — with static\n"
        "    batching every bar would end at the time of the longest one.\n"
        "  * Bars starting later (staggered arrivals) join the running batch\n"
        "    immediately - admission happens per token-iteration, not per batch.\n"
    )


async def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[2])
    ap.add_argument("--base-url", default="http://localhost:8000")
    ap.add_argument("--num-requests", type=int, default=8)
    ap.add_argument("--stagger", type=float, default=1.5,
                    help="seconds between request launches")
    args = ap.parse_args()

    client = AsyncOpenAI(base_url=args.base_url + "/v1", api_key="not-needed")
    port = int(args.base_url.rsplit(":", 1)[-1])

    models = await client.models.list()
    model = models.data[0].id
    print(f"Server OK — model: {model}")
    print(f"Sending {args.num_requests} requests, one every {args.stagger}s, "
          f"output lengths {MAX_TOKENS_PATTERN[:args.num_requests]}\n")

    t0 = time.perf_counter()
    stop = asyncio.Event()
    watcher = asyncio.create_task(metrics_watcher(port, t0, stop))

    results: dict = {}
    tasks = []
    for i in range(args.num_requests):
        max_tokens = MAX_TOKENS_PATTERN[i % len(MAX_TOKENS_PATTERN)]
        tasks.append(asyncio.create_task(
            one_request(client, model, i, max_tokens, t0, results)))
        await asyncio.sleep(args.stagger)

    await asyncio.gather(*tasks)
    stop.set()
    await watcher

    print_timeline(results)


if __name__ == "__main__":
    asyncio.run(main())
