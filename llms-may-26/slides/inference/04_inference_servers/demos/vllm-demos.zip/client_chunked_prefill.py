"""
client_chunked_prefill.py
=========================
Shows WHY chunked prefill exists: a huge prompt arriving mid-stream either
stalls every decoding request (big prefill budget) or slides in smoothly
(small budget → prefill split into chunks interleaved with decode steps).

Protocol:
  1. N "chatty" clients stream short completions and record every
     inter-token gap (ITL).
  2. After a few seconds, ONE huge prompt (~several thousand tokens) arrives.
  3. Report each chatty client's median / p99 / max ITL and WHEN the max
     happened — with a large prefill budget the max gap lines up exactly
     with the big prompt's arrival.

Run it twice against two server configs and compare:

    # A: big budget — the whole prefill lands in one iteration (stall)
    ./serve.sh --max-num-batched-tokens 16384
    python client_chunked_prefill.py

    # B: small budget — prefill chunked, decode keeps flowing (smooth)
    ./serve.sh --max-num-batched-tokens 2048
    python client_chunked_prefill.py

Prerequisites: pip install openai

Usage:
    python client_chunked_prefill.py
    python client_chunked_prefill.py --decoders 8 --prompt-words 9000
"""

import argparse
import asyncio
import statistics
import time

from openai import AsyncOpenAI

FILLER_SENTENCE = (
    "The quick brown fox jumps over the lazy dog while the scheduler "
    "keeps every streaming request supplied with fresh tokens. "
)


async def chatty_decoder(client, model, idx, t0, out, max_tokens):
    """Stream a completion, recording (timestamp, gap) for every token."""
    gaps = []
    last = None
    stream = await client.completions.create(
        model=model,
        prompt=f"Client {idx}: tell me a long story about a space mission.",
        max_tokens=max_tokens,
        temperature=0.7,
        stream=True,
        extra_body={"ignore_eos": True},
    )
    async for _chunk in stream:
        now = time.perf_counter() - t0
        if last is not None:
            gaps.append((now, now - last))
        last = now
    out[idx] = gaps


async def big_prefill(client, model, t0, words, marker):
    prompt = FILLER_SENTENCE * (words // len(FILLER_SENTENCE.split()))
    prompt += "\nSummarize the text above in one sentence:"
    marker["sent"] = time.perf_counter() - t0
    print(f"  [{marker['sent']:6.1f}s] >>> BIG PROMPT sent "
          f"(~{words} words ≈ {int(words * 1.3)} tokens)")
    resp = await client.completions.create(
        model=model, prompt=prompt, max_tokens=32, temperature=0.0,
    )
    marker["done"] = time.perf_counter() - t0
    print(f"  [{marker['done']:6.1f}s] >>> BIG PROMPT completed "
          f"({len(resp.choices[0].text.split())} words out)")


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000")
    ap.add_argument("--decoders", type=int, default=6)
    ap.add_argument("--max-tokens", type=int, default=400,
                    help="tokens each chatty decoder generates")
    ap.add_argument("--prompt-words", type=int, default=7000,
                    help="size of the big prompt (words; tokens ≈ 1.3x). "
                         "Must fit in the server's --max-model-len.")
    ap.add_argument("--delay", type=float, default=6.0,
                    help="seconds of smooth decoding before the big prompt")
    args = ap.parse_args()

    client = AsyncOpenAI(base_url=args.base_url + "/v1", api_key="not-needed")
    models = await client.models.list()
    model = models.data[0].id
    print(f"Server OK — model: {model}")
    print(f"{args.decoders} streaming decoders + 1 big prompt after "
          f"{args.delay}s\n")

    t0 = time.perf_counter()
    out: dict = {}
    marker: dict = {}

    decoders = [asyncio.create_task(
        chatty_decoder(client, model, i, t0, out, args.max_tokens))
        for i in range(args.decoders)]

    await asyncio.sleep(args.delay)
    injector = asyncio.create_task(
        big_prefill(client, model, t0, args.prompt_words, marker))

    await asyncio.gather(*decoders, injector)

    print("\nPer-decoder inter-token latency (ITL):")
    print(f"  {'client':>6} {'median':>9} {'p99':>9} {'max':>9} {'max @':>8}")
    worst = 0.0
    for idx in sorted(out):
        gaps = out[idx]
        if not gaps:
            continue
        vals = sorted(g for _, g in gaps)
        p99 = vals[min(int(len(vals) * 0.99), len(vals) - 1)]
        t_max, g_max = max(gaps, key=lambda x: x[1])
        worst = max(worst, g_max)
        print(f"  r{idx:<5d} {statistics.median(vals) * 1000:8.1f}ms "
              f"{p99 * 1000:8.1f}ms {g_max * 1000:8.1f}ms {t_max:7.1f}s")

    if "sent" in marker:
        print(f"\nBig prompt was sent at t={marker['sent']:.1f}s "
              f"(finished t={marker.get('done', 0):.1f}s).")
    print(
        "\nHow to read this:\n"
        "  * If 'max @' clusters right after the big-prompt timestamp and max\n"
        "    ITL >> median: the prefill monopolized whole iterations (stall).\n"
        "  * With a small --max-num-batched-tokens the prefill is chunked and\n"
        "    max ITL stays close to p99: latency smoothness bought with a\n"
        "    slightly slower big-prompt completion. That's the tradeoff knob.\n"
    )


if __name__ == "__main__":
    asyncio.run(main())
