#!/usr/bin/env bash
# =============================================================================
# bench.sh — the standard benchmark workload for ALL demo comparisons.
#
# Identical to the workload recorded in /projects/vllm/bench_results.md, so
# every new number can be compared against the existing baselines:
#   random dataset, 1024 input tokens, 256 output tokens,
#   24 prompts, max 4 concurrent.
#
# The model name is fetched automatically from the running server.
#
# Usage:
#   ./bench.sh                          # standard workload
#   ./bench.sh --num-prompts 48         # override anything
#   CONCURRENCY=16 ./bench.sh           # heavier concurrency
#
# Key numbers to read from the report:
#   TTFT   (time to first token)  — prefill latency; median vs P99 tells the
#                                    warmup/burst story
#   TPOT   (time per output token) — decode speed per stream
#   ITL    (inter-token latency)   — what a user actually feels between tokens
#   Output token throughput        — aggregate serving capacity
# =============================================================================
set -euo pipefail

PORT=${PORT:-8000}
VLLM_BIN=${VLLM_BIN:-/projects/vllm/bin/vllm}
command -v "$VLLM_BIN" >/dev/null 2>&1 || VLLM_BIN=vllm

NUM_PROMPTS=${NUM_PROMPTS:-24}
CONCURRENCY=${CONCURRENCY:-4}
INPUT_LEN=${INPUT_LEN:-1024}
OUTPUT_LEN=${OUTPUT_LEN:-256}

exec "$VLLM_BIN" bench serve \
    --base-url "http://localhost:$PORT" \
    --dataset-name random \
    --random-input-len "$INPUT_LEN" \
    --random-output-len "$OUTPUT_LEN" \
    --num-prompts "$NUM_PROMPTS" \
    --max-concurrency "$CONCURRENCY" \
    "$@"
