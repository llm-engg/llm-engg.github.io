#!/usr/bin/env bash
# =============================================================================
# watch_metrics.sh — live view of the vLLM Prometheus counters that matter
# for the serving demos: batch occupancy, KV-cache usage, prefix-cache hits,
# and preemptions.
#
# Run in a second terminal next to any demo client.
#
# Usage:
#   ./watch_metrics.sh            # poll localhost:8000 every 2s
#   PORT=8001 INTERVAL=1 ./watch_metrics.sh
# =============================================================================
PORT=${PORT:-8000}
INTERVAL=${INTERVAL:-2}

while true; do
  clear
  echo "vLLM /metrics @ localhost:$PORT   $(date '+%T')   (Ctrl-C to stop)"
  echo "----------------------------------------------------------------"
  curl -s --max-time 2 "localhost:$PORT/metrics" \
    | grep -E 'vllm:(num_requests_(running|waiting)|kv_cache_usage_perc|gpu_cache_usage_perc|prefix_cache_(queries|hits)|num_preemptions)' \
    | grep -v '^#' \
    || echo "  (server not reachable on :$PORT yet)"
  sleep "$INTERVAL"
done
