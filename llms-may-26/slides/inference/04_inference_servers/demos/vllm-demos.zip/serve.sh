#!/usr/bin/env bash
# =============================================================================
# serve.sh — generic vLLM demo server launcher
#
# Starts an OpenAI-compatible vLLM server with DEBUG logging so the scheduler,
# KV-cache manager, and batch composition are visible in the log.
#
# Usage:
#   ./serve.sh                                    # Qwen3-0.6B, debug logging
#   MODEL=Qwen/Qwen3-4B-Instruct-2507 ./serve.sh  # different model
#   GPU_UTIL=0.9 ./serve.sh                       # bigger KV-cache pool
#   ./serve.sh --kv-cache-dtype fp8               # extra vllm flags pass through
#   ./serve.sh --num-gpu-blocks-override 2048     # tiny KV pool (preemption demo)
#
# Env knobs (all optional):
#   MODEL      HF model id                    (default Qwen/Qwen3-0.6B)
#   PORT       server port                    (default 8000)
#   GPU_UTIL   --gpu-memory-utilization       (default 0.5)
#   MAX_LEN    --max-model-len                (default 16384)
#   MAX_SEQS   --max-num-seqs                 (default 64)
#   DEBUG      1 = VLLM_LOGGING_LEVEL=DEBUG   (default 1)
#   HF_OFFLINE 1 = no Hub network access      (default 1; set 0 on first download)
#   VLLM_BIN   path to the vllm executable    (default /projects/vllm/bin/vllm)
# =============================================================================
set -euo pipefail

MODEL=${MODEL:-Qwen/Qwen3-0.6B}
PORT=${PORT:-8000}
GPU_UTIL=${GPU_UTIL:-0.5}
MAX_LEN=${MAX_LEN:-16384}
MAX_SEQS=${MAX_SEQS:-64}
DEBUG=${DEBUG:-1}
VLLM_BIN=${VLLM_BIN:-/projects/vllm/bin/vllm}
command -v "$VLLM_BIN" >/dev/null 2>&1 || VLLM_BIN=vllm

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
LOG_DIR=${LOG_DIR:-$SCRIPT_DIR/logs}
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/serve-$(date +%Y%m%d-%H%M%S).log"

# Models are assumed pre-downloaded (hf download <model>); offline mode avoids
# network stalls mid-demo. First run of a new model: HF_OFFLINE=0 ./serve.sh
export HF_HUB_OFFLINE=${HF_OFFLINE:-1}
export TRANSFORMERS_OFFLINE=${HF_OFFLINE:-1}
export VLLM_NO_USAGE_STATS=1
export DO_NOT_TRACK=1
if [ "$DEBUG" = "1" ]; then
  export VLLM_LOGGING_LEVEL=DEBUG
fi


if ss -tln 2>/dev/null | grep -q ":$PORT "; then
  echo "ABORT: port $PORT already in use — run ONE server at a time."
  exit 1
fi

echo "============================================="
echo " vLLM demo server"
echo " Model    : $MODEL"
echo " Port     : $PORT"
echo " GPU util : $GPU_UTIL   Max len: $MAX_LEN   Max seqs: $MAX_SEQS"
echo " Extra    : $*"
echo " Log      : $LOG_FILE"
echo "============================================="

echo "running", "$VLLM_BIN" serve "$MODEL" \
    --host 0.0.0.0 \
    --port "$PORT" \
    --gpu-memory-utilization "$GPU_UTIL" \
    --max-model-len "$MAX_LEN" \
    --max-num-seqs "$MAX_SEQS" \
    --enable-prefix-caching \
    "$@" 2>&1 | tee "$LOG_FILE"

"$VLLM_BIN" serve "$MODEL" \
    --host 0.0.0.0 \
    --port "$PORT" \
    --gpu-memory-utilization "$GPU_UTIL" \
    --max-model-len "$MAX_LEN" \
    --max-num-seqs "$MAX_SEQS" \
    --enable-prefix-caching \
    "$@" 2>&1 | tee "$LOG_FILE"

